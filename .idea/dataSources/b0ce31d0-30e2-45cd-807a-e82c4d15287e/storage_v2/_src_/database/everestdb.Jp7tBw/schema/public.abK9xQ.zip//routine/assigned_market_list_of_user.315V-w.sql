create function assigned_market_list_of_user(p_organization_id bigint, p_user_id bigint) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_list BIGINT [];
BEGIN
    SELECT array(
             SELECT um.market_id
             FROM
                 user_markets um
                     LEFT JOIN markets m ON um.market_id = m.id
             WHERE
                     m.is_active = TRUE
               AND m.organization_id = p_organization_id
               AND um.user_id = p_user_id
               )
           INTO market_list;
    RETURN market_list;
END;
$$;

alter function assigned_market_list_of_user(bigint, bigint) owner to bizmotion_user;

