create function chambers_delete_trigger_function() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO chambers_history (id, is_active, is_deleted, last_timestamp, created_at, created_by, updated_at, updated_by, doctor_id, chamber_type_id,
                                name, address, phone_number, latitude, longitude, image, organization_id, practice_day_count, remarks, deleted_at)
  VALUES (OLD.id, OLD.is_active, OLD.is_deleted, OLD.last_timestamp, OLD.created_at, OLD.created_by, OLD.updated_at, OLD.updated_by, OLD.doctor_id,
          OLD.chamber_type_id, OLD.name, OLD.address, OLD.phone_number, OLD.latitude, OLD.longitude, OLD.image, OLD.organization_id,
          OLD.practice_day_count, OLD.remarks, now());
  RETURN NULL;
END;
$$;

alter function chambers_delete_trigger_function() owner to bizmotion_user;

