create materialized view survey_question_options as
SELECT q.id                                                      AS question_id,
       q.is_active                                               AS active,
       q.organization_id                                         AS org_id,
       q.survey_id,
       q.question_type,
       q.question,
       q.sequence,
       q.weight,
       q.score,
       array_agg(o.id) FILTER (WHERE o.id IS NOT NULL)           AS option_id_list,
       array_agg(o.is_active) FILTER (WHERE o.id IS NOT NULL)    AS option_active_list,
       array_agg(o.option_value) FILTER (WHERE o.id IS NOT NULL) AS option_value_list,
       array_agg(o.sequence) FILTER (WHERE o.id IS NOT NULL)     AS option_sequence_list,
       array_agg(o.weight) FILTER (WHERE o.id IS NOT NULL)       AS option_weight_list,
       array_agg(o.score) FILTER (WHERE o.id IS NOT NULL)        AS option_score_list
FROM survey_questions q
         LEFT JOIN question_options o ON q.id = o.question_id
WHERE q.is_active = true
GROUP BY q.id, q.is_active, q.organization_id, q.survey_id, q.question_type, q.question, q.sequence, q.weight, q.score;

alter materialized view survey_question_options owner to bizmotion_user;

create unique index survey_question_options_index
    on survey_question_options (question_id);

