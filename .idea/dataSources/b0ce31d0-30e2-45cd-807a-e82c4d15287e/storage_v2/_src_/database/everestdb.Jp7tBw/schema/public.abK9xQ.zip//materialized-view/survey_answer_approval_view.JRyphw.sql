create materialized view survey_answer_approval_view as
WITH approval_view AS (SELECT sa_1.response_id                                                AS survey_response_id,
                              array_to_json(array_agg(sa_1.id))::text                         AS approval_id_list,
                              array_to_json(array_agg(sa_1.created_at))::text                 AS approval_time_list,
                              array_to_json(array_agg(sa_1.is_approved))::text                AS approval_list,
                              array_to_json(array_agg(approver.user_id))::text                AS approver_id_list,
                              array_to_json(array_agg(approver.code))::text                   AS approver_code_list,
                              array_to_json(array_agg(approver.name))::text                   AS approver_name_list,
                              array_to_json(array_agg(approver.designation))::text            AS approver_designation_list,
                              array_to_json(array_agg(approver.role_id))::text                AS approver_role_id_list,
                              array_to_json(array_agg(approver.role_name))::text              AS approver_role_name_list,
                              array_to_json(array_agg(approver.role_market_level_id))::text   AS approver_level_id_list,
                              array_to_json(array_agg(approver.role_market_level_name))::text AS approver_level_name_list,
                              array_to_json(array_agg(approver.role_market_level_rank))::text AS approver_level_rank_list,
                              array_to_json(array_agg(sa_1.approval_note))::text              AS approval_note_list,
                              max(sa_1.id)                                                    AS last_state_id,
                              min(approver.role_market_level_rank)                            AS last_approver_rank
                       FROM survey_answer_approvals sa_1
                                LEFT JOIN user_details_info_view approver ON sa_1.approved_by = approver.user_id
                       GROUP BY sa_1.response_id)
SELECT sr.id                                        AS survey_response_id,
       av.approval_id_list,
       av.approval_time_list,
       av.approval_list,
       av.approval_note_list,
       av.approver_id_list,
       av.approver_code_list,
       av.approver_name_list,
       av.approver_designation_list,
       av.approver_role_id_list,
       av.approver_role_name_list,
       av.approver_level_id_list,
       av.approver_level_name_list,
       av.approver_level_rank_list,
       count(par.id)                                AS rule_count,
       sa.is_approved                               AS last_state,
       CASE
           WHEN sa.is_approved = false THEN NULL::integer
           ELSE av.last_approver_rank
           END                                      AS last_approver_rank,
       COALESCE(max(sup.role_market_level_rank), 0) AS next_approval_rank
FROM survey_respondents sr
         LEFT JOIN approval_view av ON sr.id = av.survey_response_id
         LEFT JOIN survey_answer_approvals sa ON av.last_state_id = sa.id
         LEFT JOIN user_details_info_view surveyer ON sr.created_by = surveyer.user_id
         LEFT JOIN market_details_view mdv ON mdv.market_id = ANY (surveyer.market_id_list)
         LEFT JOIN approval_rules par ON sr.is_approved IS NULL AND surveyer.role_id = par.request_of AND
                                         (sr.doctor_id IS NULL OR
                                          par.resource = 'APPROVE_DOCTOR_SURVEY_ANSWER'::text) AND
                                         (sr.customer_id IS NULL OR
                                          par.resource = 'APPROVE_CUSTOMER_SURVEY_ANSWER'::text) AND
                                         (sr.site_id IS NULL OR par.resource = 'APPROVE_SITE_SURVEY_ANSWER'::text)
         LEFT JOIN user_details_info_view sup
                   ON sup.is_active = true AND mdv.market_id_hierarchy_array && sup.market_id_list AND
                      CASE
                          WHEN sa.is_approved = false THEN surveyer.role_market_level_rank > sup.role_market_level_rank
                          ELSE COALESCE(av.last_approver_rank, surveyer.role_market_level_rank) >
                               sup.role_market_level_rank
                          END AND sup.role_id = par.approver
GROUP BY sr.id, av.approval_id_list, av.approval_time_list, av.approval_list, av.approver_id_list,
         av.approver_code_list, av.approver_name_list, av.approver_designation_list, av.approver_role_id_list,
         av.approver_role_name_list, av.approver_level_id_list, av.approver_level_name_list,
         av.approver_level_rank_list, av.last_approver_rank, av.approval_note_list, sa.is_approved;

alter materialized view survey_answer_approval_view owner to bizmotion_user;

create unique index survey_answer_approval_view_index
    on survey_answer_approval_view (survey_response_id);

