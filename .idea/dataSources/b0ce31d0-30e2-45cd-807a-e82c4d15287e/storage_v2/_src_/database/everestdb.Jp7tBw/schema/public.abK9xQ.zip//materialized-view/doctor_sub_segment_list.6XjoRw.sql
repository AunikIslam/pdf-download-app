create materialized view doctor_sub_segment_list as
SELECT doctor_id,
       array_agg(sub_segment_id) AS sub_segment_id_list
FROM doctor_sub_segments dss
GROUP BY doctor_id;

alter materialized view doctor_sub_segment_list owner to bizmotion_user;

create unique index doctor_sub_segment_list_index
    on doctor_sub_segment_list (doctor_id);

