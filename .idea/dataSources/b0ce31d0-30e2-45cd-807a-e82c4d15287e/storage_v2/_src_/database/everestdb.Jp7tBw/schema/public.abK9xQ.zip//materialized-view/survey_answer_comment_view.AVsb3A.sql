create materialized view survey_answer_comment_view as
SELECT comments.response_id,
       array_agg(comments.id)         AS id_list,
       array_agg(comments.created_at) AS time_list,
       array_agg(u.id)                AS user_id_list,
       array_agg(u.code)              AS user_code_list,
       array_agg(u.name)              AS user_name_list,
       array_agg(u.designation)       AS user_designation_list,
       array_agg(ur.id)               AS role_id_list,
       array_agg(ur.name)             AS role_name_list,
       array_agg(comments.comment)    AS comment_list
FROM survey_answer_comments comments
         LEFT JOIN users u ON comments.created_by = u.id
         LEFT JOIN user_roles ur ON u.user_role_id = ur.id
GROUP BY comments.response_id;

alter materialized view survey_answer_comment_view owner to bizmotion_user;

create unique index survey_answer_comment_view_index
    on survey_answer_comment_view (response_id);

