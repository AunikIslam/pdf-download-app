create function presentable_markets_for_sales_center_user(p_organization_id bigint, p_user_id bigint, filter_by_active_market boolean, active_market_filter boolean) returns bigint[]
    language plpgsql
as
$$
DECLARE
    _assigned_sales_centers  BIGINT[];
    _tagged_markets          BIGINT[];
    _accessible_market_list  BIGINT[];
    _enable_active_filter    BOOLEAN;
    _has_assigned_market     BOOLEAN;
    _parent_market_list      BIGINT[];
    _presentable_market_list BIGINT[];
BEGIN
    IF filter_by_active_market = TRUE AND active_market_filter = TRUE
    THEN
        _enable_active_filter = TRUE;
    ELSE
        _enable_active_filter = FALSE;
    END IF;
    SELECT array(
             SELECT usc.sales_center_id
             FROM user_sales_centers usc
                      LEFT JOIN sales_centers sc ON sc.id = usc.sales_center_id
             WHERE sc.is_active = TRUE
               AND sc.organization_id = p_organization_id
               AND usc.user_id = p_user_id
               )
    INTO _assigned_sales_centers;

    SELECT array(
             SELECT m.id
             FROM markets m
             WHERE m.sales_center_id = ANY (_assigned_sales_centers)
               AND (_enable_active_filter = FALSE OR m.is_active = TRUE)
               )
    INTO _tagged_markets;

    _accessible_market_list =
      accessible_markets_for_sales_center_user(p_organization_id, p_user_id, filter_by_active_market,
                                               active_market_filter);
    _has_assigned_market = array_length(_tagged_markets, 1) > 0;
    _parent_market_list = parent_market_list(p_organization_id, _has_assigned_market, _tagged_markets);
    _presentable_market_list = _parent_market_list || _accessible_market_list;
    RETURN _presentable_market_list;
END
$$;

alter function presentable_markets_for_sales_center_user(bigint, bigint, boolean, boolean) owner to bizmotion_user;

