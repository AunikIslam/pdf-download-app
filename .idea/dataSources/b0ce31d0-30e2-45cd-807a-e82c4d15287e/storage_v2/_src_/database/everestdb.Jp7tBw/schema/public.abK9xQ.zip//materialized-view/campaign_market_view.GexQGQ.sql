create materialized view campaign_market_view as
WITH assigned_markets AS (SELECT cm_1.campaign_id,
                                 cm_1.organization_id                                                               AS org_id,
                                 array_agg(cm_1.id)                                                                 AS campaign_market_id_list,
                                 array_agg(m.market_id)                                                             AS market_id_list,
                                 array_agg(m.market_name)                                                           AS market_name_list,
                                 array_agg(m.market_code)                                                           AS market_code_list,
                                 array_agg(m.market_active_status)                                                  AS market_active_list,
                                 array_agg(m.market_level_id)                                                       AS market_level_id_list,
                                 array_agg(m.market_level_name)                                                     AS market_level_name_list,
                                 array_agg(m.market_level_rank)                                                     AS market_level_rank_list,
                                 array_to_json(array_agg(array_to_json(m.market_id_hierarchy_array)))::text         AS market_id_hierarchy_list,
                                 array_to_json(array_agg(array_to_json(m.market_name_hierarchy_array)))::text       AS market_name_hierarchy_list,
                                 array_to_json(array_agg(array_to_json(m.market_code_hierarchy_array)))::text       AS market_code_hierarchy_list,
                                 array_to_json(array_agg(array_to_json(m.market_level_id_hierarchy_array)))::text   AS market_level_id_hierarchy_list,
                                 array_to_json(array_agg(array_to_json(m.market_level_name_hierarchy_array)))::text AS market_level_name_hierarchy_list,
                                 array_to_json(array_agg(array_to_json(m.market_level_rank_hierarchy_array)))::text AS market_level_rank_hierarchy_list
                          FROM campaign_markets cm_1
                                   LEFT JOIN market_details_view m ON cm_1.market_id = m.market_id
                          GROUP BY cm_1.campaign_id, cm_1.organization_id)
SELECT campaign_id,
       campaign_market_id_list,
       market_id_list,
       market_name_list,
       market_code_list,
       market_active_list,
       market_level_id_list,
       market_level_name_list,
       market_level_rank_list,
       market_id_hierarchy_list,
       market_name_hierarchy_list,
       market_code_hierarchy_list,
       market_level_id_hierarchy_list,
       market_level_name_hierarchy_list,
       market_level_rank_hierarchy_list,
       associated_market_list_including(org_id, true, market_id_list, true, true) AS applied_market_list
FROM assigned_markets cm;

alter materialized view campaign_market_view owner to bizmotion_user;

create unique index campaign_market_view_index
    on campaign_market_view (campaign_id);

