create materialized view chemist_view as
WITH market_hierarchy AS (SELECT t.id                               AS ref_id,
                                 array_agg(DISTINCT t.hierarchy_id) AS market_id_hierarchy
                          FROM (SELECT mr.chemist_id                         AS id,
                                       unnest(mdv.market_id_hierarchy_array) AS hierarchy_id
                                FROM chemist_markets mr
                                         LEFT JOIN market_details_view mdv ON mr.market_id = mdv.market_id) t
                          GROUP BY t.id),
     chemist_update_time(chemist_id, last_update_time) AS (SELECT c_1.id             AS chemist_id,
                                                                  c_1.last_timestamp AS last_updated_time
                                                           FROM chemists c_1
                                                           UNION ALL
                                                           SELECT cm_1.chemist_id,
                                                                  cm_1.last_timestamp
                                                           FROM chemist_markets cm_1
                                                           UNION ALL
                                                           SELECT ca.chemist_id,
                                                                  ca.created_at
                                                           FROM chemist_approvals ca),
     chemist_last_update_time(chemist_id, last_update_time) AS (SELECT c_1.chemist_id,
                                                                       max(c_1.last_update_time) AS last_updated_time
                                                                FROM chemist_update_time c_1
                                                                GROUP BY c_1.chemist_id),
     chemist_approval_list AS (SELECT c_1.id,
                                      COALESCE(min(approver.role_market_level_rank),
                                               requested_by.role_market_level_rank, 0)                 AS last_approval_rank,
                                      array_to_json(array_agg(approval.id))::jsonb                     AS approval_id_list,
                                      array_to_json(array_agg(approval.created_at))::jsonb             AS approval_time_list,
                                      array_to_json(array_agg(approver.user_id))::jsonb                AS approver_id_list,
                                      array_to_json(array_agg(approver.code))::jsonb                   AS approver_code_list,
                                      array_to_json(array_agg(approver.name))::jsonb                   AS approver_name_list,
                                      array_to_json(array_agg(approver.designation))::jsonb            AS approver_designation_list,
                                      array_to_json(array_agg(approver.role_id))::jsonb                AS approver_role_id_list,
                                      array_to_json(array_agg(approver.role_name))::jsonb              AS approver_role_name_list,
                                      array_to_json(array_agg(approver.role_market_level_id))::jsonb   AS approver_level_id_list,
                                      array_to_json(array_agg(approver.role_market_level_name))::jsonb AS approver_level_name_list,
                                      array_to_json(array_agg(approver.role_market_level_rank))::jsonb AS approver_level_rank_list
                               FROM chemists c_1
                                        LEFT JOIN user_details_info_view requested_by
                                                  ON c_1.created_by = requested_by.user_id
                                        LEFT JOIN chemist_approvals approval ON c_1.id = approval.chemist_id
                                        LEFT JOIN user_view approver ON approval.approved_by = approver.user_id
                                        LEFT JOIN chemist_last_update_time clut ON c_1.id = clut.chemist_id
                                        LEFT JOIN customer_sub_segment_list css_1 ON c_1.id = css_1.customer_id
                               GROUP BY c_1.id, requested_by.role_market_level_rank)
SELECT c.id,
       c.organization_id                                                            AS org_id,
       c.is_active                                                                  AS active,
       c.created_by,
       c.created_at,
       c.is_approved,
       c.approved_by,
       c.code,
       c.secondary_code,
       c.name,
       c.phone,
       c.mobile,
       c.email,
       c.chemist_type_id                                                            AS type_id,
       c.sales_center_id,
       sc.name                                                                      AS sales_center_name,
       sc.code                                                                      AS sales_center_code,
       sc.is_active                                                                 AS sales_center_active,
       array_agg(cm.id)                                                             AS chemist_market_id_list,
       array_agg(m.market_id)                                                       AS market_id_list,
       array_agg(m.market_name)                                                     AS market_name_list,
       array_agg(m.market_code)                                                     AS market_code_list,
       array_agg(m.market_active_status)                                            AS market_activestatus_list,
       array_agg(m.market_level_id)                                                 AS market_level_id_list,
       array_agg(m.market_level_name)                                               AS market_level_name_list,
       array_agg(m.market_level_rank)                                               AS market_level_rank_list,
       array_to_json(array_agg(cm.id))                                              AS chemist_market_id_list_json,
       array_to_json(array_agg(m.market_id))                                        AS market_id_list_json,
       array_to_json(array_agg(m.market_name))                                      AS market_name_list_json,
       array_to_json(array_agg(m.market_code))                                      AS market_code_list_json,
       array_to_json(array_agg(m.market_active_status))                             AS market_activestatus_list_json,
       array_to_json(array_agg(m.market_level_id))                                  AS market_level_id_list_json,
       array_to_json(array_agg(m.market_level_name))                                AS market_level_name_list_json,
       array_to_json(array_agg(m.market_level_rank))                                AS market_level_rank_list_json,
       array_to_json(array_agg(array_to_json(m.market_id_hierarchy_array)))         AS market_id_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_name_hierarchy_array)))       AS market_name_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_code_hierarchy_array)))       AS market_code_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_id_hierarchy_array)))   AS market_level_id_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_name_hierarchy_array))) AS market_level_name_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_rank_hierarchy_array))) AS market_level_rank_hierarchy_list,
       array_agg(m.sales_center_id)                                                 AS market_sales_center_id_list,
       array_to_json(array_agg(m.sales_center_id))                                  AS market_sales_center_id_list_json,
       array_to_json(array_agg(msc.name))                                           AS market_sales_center_name_list_json,
       array_to_json(array_agg(msc.code))                                           AS market_sales_center_code_list_json,
       array_to_json(array_agg(msc.is_active))                                      AS market_sales_center_active_list_json,
       mh.market_id_hierarchy,
       update_time.last_update_time,
       approvals.last_approval_rank,
       approvals.approval_id_list,
       approvals.approval_time_list,
       approvals.approver_id_list,
       approvals.approver_code_list,
       approvals.approver_name_list,
       approvals.approver_designation_list,
       approvals.approver_role_id_list,
       approvals.approver_role_name_list,
       approvals.approver_level_id_list,
       approvals.approver_level_name_list,
       approvals.approver_level_rank_list,
       array_to_json(array_agg(cpl.id))                                             AS chemist_product_line_id_list_json,
       array_agg(pl.id)                                                             AS product_line_id_list,
       array_to_json(array_agg(pl.id))                                              AS product_line_id_list_json,
       array_to_json(array_agg(pl.name))                                            AS product_line_name_list_json,
       array_to_json(array_agg(pl.is_active))                                       AS product_line_active_list_json,
       array_to_json(array_agg(css.id))                                             AS chemist_sub_segment_id_list_json,
       array_agg(ss.id)                                                             AS sub_segment_id_list,
       array_to_json(array_agg(ss.id))                                              AS sub_segment_id_list_json,
       array_to_json(array_agg(ss.is_active))                                       AS sub_segment_active_list_json,
       array_to_json(array_agg(ss.name))                                            AS sub_segment_name_list_json,
       array_to_json(array_agg(s.id))                                               AS segment_id_list_json,
       array_to_json(array_agg(s.is_active))                                        AS segment_active_list_json,
       array_to_json(array_agg(s.name))                                             AS segment_name_list_json
FROM chemists c
         LEFT JOIN sales_centers sc ON c.sales_center_id = sc.id
         LEFT JOIN chemist_markets cm ON c.id = cm.chemist_id
         LEFT JOIN market_details_view m ON cm.market_id = m.market_id
         LEFT JOIN sales_centers msc ON m.sales_center_id = msc.id
         LEFT JOIN market_hierarchy mh ON c.id = mh.ref_id
         LEFT JOIN chemist_last_update_time update_time ON c.id = update_time.chemist_id
         LEFT JOIN chemist_approval_list approvals ON c.id = approvals.id
         LEFT JOIN chemist_product_lines cpl ON c.id = cpl.chemist_id
         LEFT JOIN product_lines pl ON cpl.product_line_id = pl.id
         LEFT JOIN chemist_sub_segments css ON c.id = css.chemist_id
         LEFT JOIN sub_segments ss ON css.sub_segment_id = ss.id
         LEFT JOIN segments s ON ss.segment_id = s.id
GROUP BY c.id, c.organization_id, c.is_active, c.created_by, c.created_at, c.is_approved, c.approved_by, c.code,
         c.secondary_code, c.name, c.phone, c.mobile, c.email, c.chemist_type_id, c.sales_center_id, sc.name, sc.code,
         sc.is_active, mh.market_id_hierarchy, update_time.last_update_time, approvals.last_approval_rank,
         approvals.approval_id_list, approvals.approval_time_list, approvals.approver_id_list,
         approvals.approver_code_list, approvals.approver_name_list, approvals.approver_designation_list,
         approvals.approver_role_id_list, approvals.approver_role_name_list, approvals.approver_level_id_list,
         approvals.approver_level_name_list, approvals.approver_level_rank_list;

alter materialized view chemist_view owner to bizmotion_user;

create unique index chemist_view_index
    on chemist_view (id);

