create view doctor_market_details_view
            (doctor_market_id, doctor_id, market_id, category_id, category_name, weight, dcr_allowed,
             avg_prescription_count, doctor_market_patient_id_list, patient_types_id_list, patient_types_name_list,
             avg_patient_count)
as
SELECT dm.id                            AS doctor_market_id,
       dm.doctor_id,
       dm.market_id,
       dm.category_id,
       dc.name                          AS category_name,
       dm.weight,
       dm.dcr_allowed,
       dm.avg_prescription_count,
       array_agg(dmp.id)                AS doctor_market_patient_id_list,
       array_agg(pt.id)                 AS patient_types_id_list,
       array_agg(pt.name)               AS patient_types_name_list,
       array_agg(dmp.avg_patient_count) AS avg_patient_count
FROM doctor_markets dm
         LEFT JOIN markets m ON m.id = dm.market_id
         LEFT JOIN doctor_categories dc ON dc.id = dm.category_id
         LEFT JOIN doctor_market_patient dmp ON dmp.doctor_market_id = dm.id
         LEFT JOIN patient_types pt ON pt.id = dmp.patient_type_id
WHERE m.is_active = true
GROUP BY dm.id, dm.doctor_id, dm.market_id, dm.category_id, dc.name, dm.weight, dm.dcr_allowed,
         dm.avg_prescription_count;

alter table doctor_market_details_view
    owner to bizmotion_user;

