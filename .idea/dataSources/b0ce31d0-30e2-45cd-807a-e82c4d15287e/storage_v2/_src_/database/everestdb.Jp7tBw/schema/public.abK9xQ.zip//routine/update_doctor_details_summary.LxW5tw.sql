create function update_doctor_details_summary(doctor_id_list bigint[]) returns void
    language plpgsql
as
$$
BEGIN
    WITH doctor_details AS
             (SELECT d.id                                              AS doctor_id,
                     array_agg(dg.id)                                  AS doctor_degree_id_array,
                     jsonb_agg(dg.id)                                  AS doctor_degree_id_list,
                     array_agg(deg.id)                                 AS degree_id_array,
                     jsonb_agg(deg.id)                                 AS degree_id_list,
                     jsonb_agg(deg.name)                               AS degree_name_list,
                     array_agg(ds.id)                                  AS doctor_speciality_id_array,
                     jsonb_agg(ds.id)                                  AS doctor_speciality_id_list,
                     array_agg(sp.id)                                  AS speciality_id_array,
                     jsonb_agg(sp.id)                                  AS speciality_id_list,
                     jsonb_agg(sp.name)                                AS speciality_name_list,
                     array_agg(dss.id)                                 AS doctor_sub_segment_id_array,
                     jsonb_agg(dss.id)                                 AS doctor_sub_segment_id_list,
                     array_agg(ssg.id)                                 AS sub_segment_id_array,
                     jsonb_agg(ssg.id)                                 AS sub_segment_id_list,
                     jsonb_agg(ssg.name)                               AS sub_segment_name_list,
                     jsonb_agg(sg.id)                                  AS segment_id_list,
                     jsonb_agg(sg.name)                                AS segment_name_list,
                     array_agg(dm.market_id)                           AS doctor_market_id_array,
                     jsonb_agg(dm.market_id)                           AS doctor_market_id_list,
                     array_agg(m.market_id)                            AS marketIdarray,
                     json_agg(m.market_id)                             AS marketIdList,
                     json_agg(m.market_code)                           AS marketCodeList,
                     json_agg(m.market_name)                           AS marketNameList,
                     json_agg(m.market_active_status)                  AS marketActiveStatusList,
                     array_agg(m.market_level_id)                      AS marketLevelIdArray,
                     json_agg(m.market_level_id)                       AS marketLevelIdList,
                     json_agg(m.market_level_name)                     AS marketLevelNameList,
                     json_agg(m.market_level_rank)                     AS marketLevelRankList,
                     array_agg_mult(m.market_id_hierarchy_array)       AS marketIdHierarchyArray,
                     json_agg(m.market_id_hierarchy)                   AS marketIdHierarchyList,
                     json_agg(m.market_name_hierarchy)                 AS marketNameHierarchyList,
                     json_agg(m.market_code_hierarchy)                 AS marketCodeHierarchyList,
                     array_agg_mult(m.market_level_id_hierarchy_array) AS marketLevelIdHierarchyArray,
                     json_agg(m.market_level_id_hierarchy)             AS marketLevelIdHierarchyList,
                     json_agg(m.market_level_name_hierarchy)           AS marketLevelNameHierarchyList,
                     json_agg(m.market_level_rank_hierarchy)           AS marketLevelRankHierarchyList,
                     array_agg(dc.id)                                  as category_id_array,
                     json_agg(dc.id)                                   as category_id_list,
                     json_agg(dc.name)                                 as category_name_list,
                     array_agg(DISTINCT db.brand_id)                   AS brand_id_array
              FROM doctors d
                       LEFT JOIN doctor_degrees dg ON d.id = dg.doctor_id
                       LEFT JOIN academic_degrees deg ON dg.degree_id = deg.id
                       LEFT JOIN doctor_specialities ds ON d.id = ds.doctor_id
                       LEFT JOIN specialities sp ON ds.speciality_id = sp.id
                       LEFT JOIN doctor_sub_segments dss ON d.id = dss.doctor_id
                       LEFT JOIN sub_segments ssg ON dss.sub_segment_id = ssg.id
                       LEFT JOIN segments sg ON ssg.segment_id = sg.id
                       LEFT JOIN doctor_markets dm ON d.id = dm.doctor_id
                       LEFT JOIN market_details m ON dm.market_id = m.market_id
                       LEFT JOIN doctor_categories dc ON dm.category_id = dc.id
                       LEFT JOIN doctor_brands db ON d.id = db.doctor_id
              WHERE d.id = ANY (doctor_id_list)
              GROUP BY d.id)
    INSERT
    INTO doctor_details_summary(doctor_id, doctor_degree_id_array, doctor_degree_id_list, degree_id_array,
                                degree_id_list,
                                degree_name_list, doctor_speciality_id_array, doctor_speciality_id_list,
                                speciality_id_array, speciality_id_list, speciality_name_list,
                                doctor_sub_segment_id_array, doctor_sub_segment_id_list,
                                sub_segment_id_array, sub_segment_id_list,
                                sub_segment_name_list, segment_id_list, segment_name_list,
                                doctor_market_id_array, doctor_market_id_list, market_id_array,
                                market_id_list, market_code_list, market_name_list,
                                market_active_status_list, market_level_id_array, market_level_id_list,
                                market_level_name_list, market_level_rank_list, market_id_hierarchy_array,
                                market_id_hierarchy_list, market_name_hierarchy_list, market_code_hierarchy_list,
                                market_level_id_hierarchy_array, market_level_id_hierarchy_list,
                                market_level_name_hierarchy_list, market_level_rank_hierarchy_list,
                                category_id_array, category_id_list, category_name_list, brand_id_array)
    SELECT *
    FROM doctor_details
    ON CONFLICT (doctor_id)
        DO UPDATE
        SET doctor_degree_id_array           = excluded.doctor_degree_id_array,
            doctor_degree_id_list            = excluded.doctor_degree_id_list,
            degree_id_array                  = excluded.degree_id_array,
            degree_id_list                   = excluded.degree_id_list,
            degree_name_list                 = excluded.degree_name_list,
            doctor_speciality_id_array       = excluded.doctor_speciality_id_array,
            doctor_speciality_id_list        = excluded.doctor_speciality_id_list,
            speciality_id_array              = excluded.speciality_id_array,
            speciality_id_list               = excluded.speciality_id_list,
            speciality_name_list             = excluded.speciality_name_list,
            doctor_sub_segment_id_array      = excluded.doctor_sub_segment_id_array,
            doctor_sub_segment_id_list       = excluded.doctor_sub_segment_id_list,
            sub_segment_id_array             = excluded.sub_segment_id_array,
            sub_segment_id_list              = excluded.sub_segment_id_list,
            sub_segment_name_list            = excluded.sub_segment_name_list,
            segment_id_list                  = excluded.segment_id_list,
            segment_name_list                = excluded.segment_name_list,
            doctor_market_id_array           = excluded.doctor_market_id_array,
            doctor_market_id_list            = excluded.doctor_market_id_list,
            market_id_array                  = excluded.market_id_array,
            market_id_list                   = excluded.market_id_list,
            market_code_list                 = excluded.market_code_list,
            market_name_list                 = excluded.market_name_list,
            market_active_status_list        = excluded.market_active_status_list,
            market_level_id_array            = excluded.market_level_id_array,
            market_level_id_list             = excluded.market_level_id_list,
            market_level_name_list           = excluded.market_level_name_list,
            market_level_rank_list           = excluded.market_level_rank_list,
            market_id_hierarchy_array        = excluded.market_id_hierarchy_array,
            market_id_hierarchy_list         = excluded.market_id_hierarchy_list,
            market_name_hierarchy_list       = excluded.market_name_hierarchy_list,
            market_code_hierarchy_list       = excluded.market_code_hierarchy_list,
            market_level_id_hierarchy_array  = excluded.market_level_id_hierarchy_array,
            market_level_id_hierarchy_list   = excluded.market_level_id_hierarchy_list,
            market_level_name_hierarchy_list = excluded.market_level_name_hierarchy_list,
            market_level_rank_hierarchy_list = excluded.market_level_rank_hierarchy_list,
            category_id_array                = excluded.category_id_array,
            category_id_list                 = excluded.category_id_list,
            category_name_list               = excluded.category_name_list,
            brand_id_array                   = excluded.brand_id_array;
END;
$$;

alter function update_doctor_details_summary(bigint[]) owner to bizmotion_user;

