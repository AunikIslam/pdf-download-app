create function is_between_date(query_from_date date, query_to_date date, event_date date) returns boolean
    language plpgsql
as
$$
DECLARE
    RES BOOLEAN;
BEGIN
    CASE WHEN (
            (extract(month FROM query_from_date) < extract(month FROM event_date) OR
             (extract(month FROM query_from_date) = extract(month FROM event_date) AND
              extract(day FROM query_from_date) <= extract(day FROM event_date)))
            AND
            (extract(month FROM query_to_date) > extract(month FROM event_date) OR
             (extract(month FROM query_from_date) = extract(month FROM event_date) AND
              extract(day FROM query_from_date) >= extract(day FROM event_date)))
        )
        THEN RES = TRUE; ELSE RES = FALSE;
        END CASE;
    RETURN RES;
END;
$$;

alter function is_between_date(date, date, date) owner to bizmotion_user;

