create function is_between_date(query_from_date date, query_to_date date, event_date_list date[]) returns boolean
    language plpgsql
as
$$
DECLARE
    RES        BOOLEAN;
    event_date date;
BEGIN
    FOREACH event_date IN ARRAY event_date_list

        LOOP
            CASE WHEN (
                    (extract(month FROM query_from_date) < extract(month FROM event_date) OR
                     (extract(month FROM query_from_date) = extract(month FROM event_date) AND
                      extract(day FROM query_from_date) <= extract(day FROM event_date)))
                    AND
                    (extract(month FROM query_to_date) > extract(month FROM event_date) OR
                     (extract(month FROM query_to_date) = extract(month FROM event_date) AND
                      extract(day FROM query_to_date) >= extract(day FROM event_date)))
                )
                THEN RES = TRUE; ELSE RES = FALSE;
                END CASE;
            raise info 'from % % to % % event % %', extract(month FROM query_from_date), extract(day FROM query_from_date),
                extract(month FROM query_to_date), extract(day FROM query_from_date), extract(month FROM event_date), extract(day FROM event_date);
            IF RES = TRUE THEN
                RETURN TRUE;
            END IF;
        END LOOP;
    RETURN RES;
END;
$$;

alter function is_between_date(date, date, date[]) owner to bizmotion_user;

