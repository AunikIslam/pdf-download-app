create materialized view survey_market_list_view as
SELECT sm.survey_id,
       array_agg(sm.id)                                                                   AS survey_market_id_list,
       array_agg(m.market_id)                                                             AS market_id_list,
       array_agg(m.market_name)                                                           AS market_name_list,
       array_agg(m.market_code)                                                           AS market_code_list,
       array_agg(m.market_active_status)                                                  AS market_activestatus_list,
       array_agg(m.market_level_id)                                                       AS market_level_id_list,
       array_agg(m.market_level_name)                                                     AS market_level_name_list,
       array_agg(m.market_level_rank)                                                     AS market_level_rank_list,
       array_to_json(array_agg(array_to_json(m.market_id_hierarchy_array)))::text         AS market_id_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_name_hierarchy_array)))::text       AS market_name_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_code_hierarchy_array)))::text       AS market_code_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_id_hierarchy_array)))::text   AS market_level_id_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_name_hierarchy_array)))::text AS market_level_name_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_rank_hierarchy_array)))::text AS market_level_rank_hierarchy_list
FROM survey_for_markets sm
         LEFT JOIN market_details_view m ON sm.market_id = m.market_id
GROUP BY sm.survey_id;

alter materialized view survey_market_list_view owner to bizmotion_user;

create unique index survey_market_list_view_index
    on survey_market_list_view (survey_id);

