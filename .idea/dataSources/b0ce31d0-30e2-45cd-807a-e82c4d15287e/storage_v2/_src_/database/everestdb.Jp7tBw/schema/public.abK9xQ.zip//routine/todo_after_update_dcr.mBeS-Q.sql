create function todo_after_update_dcr() returns trigger
    language plpgsql
as
$$
BEGIN
  if (TG_OP = 'INSERT') then
    INSERT INTO updated_dcr(dcr_id, last_timestamp)
    VALUES (new.id, new.last_timestamp);
    RETURN new;
  elsif (TG_OP = 'UPDATE') then
    NEW.data_version = OLD.data_version + 1;
    INSERT INTO updated_dcr(dcr_id, last_timestamp)
    VALUES (new.id, new.last_timestamp);
    RETURN new;
  elsif (TG_OP = 'DELETE') then
    DELETE FROM dcr_info WHERE id = old.id;
    RETURN old;
  END IF;
END;
$$;

alter function todo_after_update_dcr() owner to bizmotion_user;

