create function todo_after_update_market_level() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO updated_markets(market_id, org_id)
  VALUES (0, new.organization_id);
  RETURN new;
END;
$$;

alter function todo_after_update_market_level() owner to bizmotion_user;

