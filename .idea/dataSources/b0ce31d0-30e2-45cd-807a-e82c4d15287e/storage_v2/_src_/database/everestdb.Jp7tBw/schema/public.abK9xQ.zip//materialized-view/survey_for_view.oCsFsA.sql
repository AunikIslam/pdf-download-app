create materialized view survey_for_view as
SELECT s.id,
       array_agg(sfd.doctor_id)   AS doctor_id_list,
       array_agg(sfc.customer_id) AS customer_id_list,
       array_agg(sfs.site_id)     AS site_id_list
FROM surveys s
         LEFT JOIN survey_for_doctors sfd ON s.id = sfd.survey_id
         LEFT JOIN survey_for_customers sfc ON s.id = sfc.survey_id
         LEFT JOIN survey_for_sites sfs ON s.id = sfs.survey_id
GROUP BY s.id;

alter materialized view survey_for_view owner to bizmotion_user;

create unique index survey_for_view_index
    on survey_for_view (id);

