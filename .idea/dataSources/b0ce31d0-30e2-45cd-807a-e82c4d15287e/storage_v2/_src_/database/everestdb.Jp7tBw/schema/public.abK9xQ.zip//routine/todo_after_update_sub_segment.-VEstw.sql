create function todo_after_update_sub_segment() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO updated_doctors(doctor_id)
  SELECT dd.doctor_id
  FROM doctor_sub_segments dd
  WHERE dd.sub_segment_id = new.id;
  RETURN new;
END;
$$;

alter function todo_after_update_sub_segment() owner to bizmotion_user;

