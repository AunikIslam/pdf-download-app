create function todo_after_update_speciality() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO updated_doctors(doctor_id)
  SELECT dd.doctor_id
  FROM doctor_specialities dd
  WHERE dd.speciality_id = new.id;
  RETURN new;
END;
$$;

alter function todo_after_update_speciality() owner to bizmotion_user;

