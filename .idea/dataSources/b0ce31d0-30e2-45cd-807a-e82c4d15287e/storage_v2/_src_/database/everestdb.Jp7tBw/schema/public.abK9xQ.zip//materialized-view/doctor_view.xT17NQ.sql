create materialized view doctor_view as
WITH market_hierarchy AS (SELECT t.id                               AS ref_id,
                                 array_agg(DISTINCT t.hierarchy_id) AS market_id_hierarchy
                          FROM (SELECT mr.doctor_id                          AS id,
                                       unnest(mdv.market_id_hierarchy_array) AS hierarchy_id
                                FROM doctor_markets mr
                                         LEFT JOIN market_details_view mdv ON mr.market_id = mdv.market_id) t
                          GROUP BY t.id),
     doctor_update_time(id, update_time) AS (SELECT d_1.id,
                                                    d_1.last_timestamp
                                             FROM doctors d_1
                                             UNION ALL
                                             SELECT dm_1.doctor_id,
                                                    dm_1.last_timestamp
                                             FROM doctor_markets dm_1
                                             UNION ALL
                                             SELECT c.doctor_id,
                                                    c.last_timestamp
                                             FROM chambers c
                                             UNION ALL
                                             SELECT di_1.doctor_id,
                                                    di_1.last_timestamp
                                             FROM institute_doctors di_1
                                             UNION ALL
                                             SELECT dc_1.doctor_id,
                                                    dc_1.last_timestamp
                                             FROM doctor_contacts dc_1
                                             UNION ALL
                                             SELECT dsd.doctor_id,
                                                    dsd.last_timestamp
                                             FROM doctor_special_days dsd
                                             UNION ALL
                                             SELECT da.doctor_id,
                                                    da.created_at
                                             FROM doctor_approvals da),
     last_update_time AS (SELECT dut.id               AS doctor_id,
                                 max(dut.update_time) AS last_update_time
                          FROM doctor_update_time dut
                          GROUP BY dut.id),
     doctor_institutes AS (SELECT di_1.doctor_id,
                                  json_agg(di_1.id)::jsonb           AS doctor_institute_id_list_json,
                                  array_agg(di_1.institute_id)       AS institute_id_list,
                                  json_agg(di_1.institute_id)::jsonb AS institute_id_list_json,
                                  json_agg(i.name)::jsonb            AS institute_name_list_json,
                                  json_agg(i.type_id)::jsonb         AS institute_type_id_list_json,
                                  json_agg(it.name)::jsonb           AS institute_type_name_list_json
                           FROM institute_doctors di_1
                                    LEFT JOIN institutes i ON di_1.institute_id = i.id
                                    LEFT JOIN institute_types it ON i.type_id = it.id
                           WHERE i.is_active = true
                           GROUP BY di_1.doctor_id),
     doctor_market_view AS (SELECT dm_1.id,
                                   dm_1.doctor_id,
                                   dm_1.market_id,
                                   dm_1.category_id,
                                   dc_1.name                              AS category_name,
                                   dm_1.weight,
                                   dm_1.dcr_allowed,
                                   dm_1.avg_prescription_count,
                                   json_agg(dmp.id)::jsonb                AS doctor_market_patient_id_list,
                                   json_agg(pt.id)::jsonb                 AS patient_type_id_list,
                                   json_agg(pt.name)::jsonb               AS patient_type_name_list,
                                   json_agg(dmp.avg_patient_count)::jsonb AS patient_type_count_list,
                                   dm_1.top_doctor
                            FROM doctor_markets dm_1
                                     LEFT JOIN markets m_1 ON m_1.id = dm_1.market_id
                                     LEFT JOIN doctor_categories dc_1 ON dc_1.id = dm_1.category_id
                                     LEFT JOIN doctor_market_patient dmp ON dmp.doctor_market_id = dm_1.id
                                     LEFT JOIN patient_types pt ON pt.id = dmp.patient_type_id
                            GROUP BY dm_1.id, dm_1.doctor_id, dm_1.market_id, dm_1.category_id, dc_1.name, dm_1.weight,
                                     dm_1.dcr_allowed, dm_1.avg_prescription_count, dm_1.top_doctor),
     approval_list AS (SELECT d_1.id,
                              COALESCE(min(approver.role_market_level_rank), requested_by.role_market_level_rank,
                                       0)                                                      AS last_approval_rank,
                              array_to_json(array_agg(approval.id))::jsonb                     AS approval_id_list,
                              array_to_json(array_agg(approval.created_at))::jsonb             AS approval_time_list,
                              array_to_json(array_agg(approver.user_id))::jsonb                AS approver_id_list,
                              array_to_json(array_agg(approver.code))::jsonb                   AS approver_code_list,
                              array_to_json(array_agg(approver.name))::jsonb                   AS approver_name_list,
                              array_to_json(array_agg(approver.designation))::jsonb            AS approver_designation_list,
                              array_to_json(array_agg(approver.role_id))::jsonb                AS approver_role_id_list,
                              array_to_json(array_agg(approver.role_name))::jsonb              AS approver_role_name_list,
                              array_to_json(array_agg(approver.role_market_level_id))::jsonb   AS approver_level_id_list,
                              array_to_json(array_agg(approver.role_market_level_name))::jsonb AS approver_level_name_list,
                              array_to_json(array_agg(approver.role_market_level_rank))::jsonb AS approver_level_rank_list
                       FROM doctors d_1
                                LEFT JOIN user_details_info_view requested_by ON d_1.created_by = requested_by.user_id
                                LEFT JOIN doctor_approvals approval ON d_1.id = approval.doctor_id
                                LEFT JOIN user_view approver ON approval.approved_by = approver.user_id
                       GROUP BY d_1.id, requested_by.role_market_level_rank)
SELECT d.id,
       d.organization_id                                            AS org_id,
       d.is_active                                                  AS active,
       d.created_by,
       d.is_approved,
       d.approved_by,
       d.code,
       d.four_p_code,
       d.name,
       d.sales_center_id,
       lut.last_update_time,
       approvals.last_approval_rank,
       approvals.approval_id_list,
       approvals.approval_time_list,
       approvals.approver_id_list,
       approvals.approver_code_list,
       approvals.approver_name_list,
       approvals.approver_designation_list,
       approvals.approver_role_id_list,
       approvals.approver_role_name_list,
       approvals.approver_level_id_list,
       approvals.approver_level_name_list,
       approvals.approver_level_rank_list,
       dinst.doctor_institute_id_list_json,
       dinst.institute_id_list_json,
       dinst.institute_id_list,
       dinst.institute_name_list_json,
       dinst.institute_type_id_list_json,
       dinst.institute_type_name_list_json,
       array_agg(dm.id)                                             AS doctor_market_id_list,
       array_agg(m.market_id)                                       AS market_id_list,
       array_agg(m.market_name)                                     AS market_name_list,
       array_agg(m.market_code)                                     AS market_code_list,
       array_agg(m.market_active_status)                            AS market_activestatus_list,
       array_agg(m.market_level_id)                                 AS market_level_id_list,
       array_agg(m.market_level_name)                               AS market_level_name_list,
       array_agg(m.market_level_rank)                               AS market_level_rank_list,
       json_agg(dm.id)                                              AS doctor_market_id_list_json,
       json_agg(m.market_id)                                        AS market_id_list_json,
       json_agg(m.market_name)                                      AS market_name_list_json,
       json_agg(m.market_code)                                      AS market_code_list_json,
       json_agg(m.market_active_status)                             AS market_activestatus_list_json,
       json_agg(m.market_level_id)                                  AS market_level_id_list_json,
       json_agg(m.market_level_name)                                AS market_level_name_list_json,
       json_agg(m.market_level_rank)                                AS market_level_rank_list_json,
       json_agg(array_to_json(m.market_id_hierarchy_array))         AS market_id_hierarchy_list,
       json_agg(array_to_json(m.market_name_hierarchy_array))       AS market_name_hierarchy_list,
       json_agg(array_to_json(m.market_code_hierarchy_array))       AS market_code_hierarchy_list,
       json_agg(array_to_json(m.market_level_id_hierarchy_array))   AS market_level_id_hierarchy_list,
       json_agg(array_to_json(m.market_level_name_hierarchy_array)) AS market_level_name_hierarchy_list,
       json_agg(array_to_json(m.market_level_rank_hierarchy_array)) AS market_level_rank_hierarchy_list,
       array_agg(m.sales_center_id)                                 AS market_sales_center_id_array,
       array_agg(dc.id)                                             AS category_id_list,
       json_agg(dc.id)                                              AS category_id_list_json,
       json_agg(dc.name)                                            AS category_name_list_json,
       array_agg(dm.weight)                                         AS weight_list,
       json_agg(dm.weight)                                          AS weight_list_json,
       array_agg(dm.dcr_allowed)                                    AS dcr_allowed_list,
       json_agg(dm.dcr_allowed)                                     AS dcr_allowed_list_json,
       json_agg(dm.avg_prescription_count)                          AS avg_prescription_count_list,
       json_agg(dm.doctor_market_patient_id_list)                   AS list_of_doctor_market_patient_id_list,
       json_agg(dm.patient_type_id_list)                            AS list_of_patient_type_id_list,
       json_agg(dm.patient_type_name_list)                          AS list_of_patient_type_name_list,
       json_agg(dm.patient_type_count_list)                         AS list_of_patient_type_count_list,
       json_agg(dm.top_doctor)                                      AS top_doctor_list_json,
       array_agg(dm.top_doctor)                                     AS top_doctor_list,
       json_agg(dspd.id)                                            AS doctor_special_day_id_list_json,
       json_agg(sd.id)                                              AS special_day_id_list_json,
       json_agg(sd.name)                                            AS special_day_name_list_json,
       json_agg(dspd.day)                                           AS special_day_date_list_json,
       array_agg(dspd.day)                                          AS special_day_date_list,
       array_agg(dcnt.contact)                                      AS contact_list,
       json_agg(dcnt.id)                                            AS doctor_contact_id_list_json,
       json_agg(ct.id)                                              AS contact_type_id_list_json,
       json_agg(ct.name)                                            AS contact_type_name_list_json,
       json_agg(dcnt.contact)                                       AS contact_list_json,
       json_agg(di.id)                                              AS doctor_image_id_list,
       json_agg(di.image)                                           AS doctor_image_file_list,
       json_agg(di.image_type)                                      AS doctor_image_type_id_list,
       json_agg(dit.name)                                           AS doctor_image_type_name_list,
       json_agg(dss.id)                                             AS doctor_sub_segment_id_list_json,
       array_agg(ss.id)                                             AS sub_segment_id_list,
       json_agg(ss.id)                                              AS sub_segment_id_list_json,
       json_agg(ss.name)                                            AS sub_segment_name_list_json,
       json_agg(ss.is_active)                                       AS sub_segment_active_list_json,
       json_agg(sg.id)                                              AS segment_id_list_json,
       json_agg(sg.name)                                            AS segment_name_list_json,
       json_agg(sg.is_active)                                       AS segment_active_list_json,
       json_agg(ch.id)                                              AS chamber_id_list,
       json_agg(ch.is_active)                                       AS chamber_active_list,
       json_agg(ch.name)                                            AS chamber_name_list,
       json_agg(ch.address)                                         AS chamber_address_list,
       json_agg(ch.image)                                           AS chamber_image_list,
       json_agg(ch.latitude)                                        AS chamber_lat_list,
       json_agg(ch.longitude)                                       AS chamber_lon_list,
       json_agg(cht.id)                                             AS chamber_type_id_list,
       json_agg(cht.is_active)                                      AS chamber_type_active_list,
       json_agg(cht.name)                                           AS chamber_type_name_list,
       json_agg(dsp.id)                                             AS doctor_speciality_id_list_json,
       json_agg(sp.id)                                              AS speciality_id_list_json,
       array_agg(sp.id)                                             AS speciality_id_list,
       json_agg(sp.name)                                            AS speciality_name_list_json,
       json_agg(dd.id)                                              AS doctor_degree_id_list_json,
       json_agg(dgr.id)                                             AS degree_id_list_json,
       array_agg(dgr.id)                                            AS degree_id_list,
       json_agg(dgr.name)                                           AS degree_name_list_json,
       json_agg(db.id)                                              AS doctor_brand_id_list_json,
       array_agg(pb.id)                                             AS brand_id_list,
       json_agg(pb.id)                                              AS brand_id_list_json,
       json_agg(pb.name)                                            AS brand_name_list_json,
       mh.market_id_hierarchy
FROM doctors d
         LEFT JOIN last_update_time lut ON d.id = lut.doctor_id
         LEFT JOIN doctor_institutes dinst ON d.id = dinst.doctor_id
         LEFT JOIN approval_list approvals ON d.id = approvals.id
         LEFT JOIN doctor_market_view dm ON d.id = dm.doctor_id
         LEFT JOIN market_details_view m ON dm.market_id = m.market_id
         LEFT JOIN market_hierarchy mh ON d.id = mh.ref_id
         LEFT JOIN doctor_categories dc ON dm.category_id = dc.id AND dc.is_active = true
         LEFT JOIN doctor_special_days dspd ON dspd.doctor_id = d.id
         LEFT JOIN special_days sd ON sd.id = dspd.special_day_id
         LEFT JOIN doctor_contacts dcnt ON dcnt.doctor_id = d.id
         LEFT JOIN contact_types ct ON ct.id = dcnt.contact_type_id
         LEFT JOIN doctor_images di ON di.doctor_id = d.id
         LEFT JOIN doctor_image_types dit ON di.image_type = dit.id
         LEFT JOIN doctor_sub_segments dss ON d.id = dss.doctor_id
         LEFT JOIN sub_segments ss ON dss.sub_segment_id = ss.id
         LEFT JOIN segments sg ON ss.segment_id = sg.id
         LEFT JOIN chambers ch ON d.id = ch.doctor_id
         LEFT JOIN chamber_types cht ON ch.chamber_type_id = cht.id
         LEFT JOIN doctor_specialities dsp ON d.id = dsp.doctor_id
         LEFT JOIN specialities sp ON dsp.speciality_id = sp.id AND sp.is_active = true
         LEFT JOIN doctor_degrees dd ON d.id = dd.doctor_id
         LEFT JOIN academic_degrees dgr ON dd.degree_id = dgr.id
         LEFT JOIN doctor_brands db ON d.id = db.doctor_id
         LEFT JOIN product_brands pb ON db.brand_id = pb.id
GROUP BY d.id, d.organization_id, d.is_active, d.created_by, d.is_approved, d.approved_by, d.code, d.four_p_code,
         d.name, d.sales_center_id, lut.last_update_time, approvals.last_approval_rank, approvals.approval_id_list,
         approvals.approval_time_list, approvals.approver_id_list, approvals.approver_code_list,
         approvals.approver_name_list, approvals.approver_designation_list, approvals.approver_role_id_list,
         approvals.approver_role_name_list, approvals.approver_level_id_list, approvals.approver_level_name_list,
         approvals.approver_level_rank_list, dinst.doctor_institute_id_list_json, dinst.institute_id_list_json,
         dinst.institute_id_list, dinst.institute_name_list_json, dinst.institute_type_id_list_json,
         dinst.institute_type_name_list_json, mh.market_id_hierarchy;

alter materialized view doctor_view owner to bizmotion_user;

create unique index doctor_view_index
    on doctor_view (id);

