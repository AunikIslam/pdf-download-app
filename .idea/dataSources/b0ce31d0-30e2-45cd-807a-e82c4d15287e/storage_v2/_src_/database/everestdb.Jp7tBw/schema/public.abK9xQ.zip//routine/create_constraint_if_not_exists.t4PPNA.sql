create function create_constraint_if_not_exists(constraint_sql text) returns void
    language plpgsql
as
$$
BEGIN
    EXECUTE constraint_sql;
EXCEPTION
    WHEN OTHERS
        THEN
            RAISE INFO 'Error Name:%', SQLERRM;
            RAISE INFO 'Error State:%', SQLSTATE;
END;
$$;

alter function create_constraint_if_not_exists(text) owner to bizmotion_user;

