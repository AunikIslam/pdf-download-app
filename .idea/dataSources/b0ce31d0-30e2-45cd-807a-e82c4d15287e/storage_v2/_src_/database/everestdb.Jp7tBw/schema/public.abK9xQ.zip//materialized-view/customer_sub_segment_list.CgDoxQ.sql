create materialized view customer_sub_segment_list as
SELECT chemist_id                AS customer_id,
       array_agg(sub_segment_id) AS sub_segment_id_list
FROM chemist_sub_segments css
GROUP BY chemist_id;

alter materialized view customer_sub_segment_list owner to bizmotion_user;

create unique index customer_sub_segment_list_index
    on customer_sub_segment_list (customer_id);

