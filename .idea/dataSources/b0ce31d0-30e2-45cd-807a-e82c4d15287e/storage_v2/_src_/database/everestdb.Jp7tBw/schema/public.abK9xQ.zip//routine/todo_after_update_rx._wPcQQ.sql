create function todo_after_update_rx() returns trigger
    language plpgsql
as
$$
BEGIN
  if (TG_OP = 'INSERT') then
    INSERT INTO updated_rx(rx_id, last_timestamp)
    VALUES (new.id, new.last_timestamp);
    RETURN new;
  elsif (TG_OP = 'UPDATE') then
    NEW.data_version = OLD.data_version + 1;
    INSERT INTO updated_rx(rx_id, last_timestamp)
    VALUES (new.id, new.last_timestamp);
    RETURN new;
  elsif (TG_OP = 'DELETE') then
    DELETE FROM rx_info WHERE id = old.id;
    RETURN old;
  END IF;
END;
$$;

alter function todo_after_update_rx() owner to bizmotion_user;

