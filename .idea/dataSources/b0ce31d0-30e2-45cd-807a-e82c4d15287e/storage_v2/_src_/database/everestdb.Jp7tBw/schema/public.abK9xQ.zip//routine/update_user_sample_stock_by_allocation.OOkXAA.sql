create function update_user_sample_stock_by_allocation(allocation_ids bigint[]) returns bigint
    language plpgsql
as
$$
DECLARE
    _previous_quantity DOUBLE PRECISION;
    _new_quantity      DOUBLE PRECISION;
    _row_count         BIGINT;
    _counter           BIGINT;
    t_row              sample_stock_allocations%rowtype;
BEGIN
    _counter := 1;
    FOR t_row IN
        SELECT *
        FROM sample_stock_allocations
        WHERE id = ANY (allocation_ids)
        LOOP
            SELECT quantity
            FROM sample_stocks
            WHERE user_id = t_row.user_id
              AND product_id = t_row.product_id
            INTO _previous_quantity;
            _previous_quantity = coalesce(_previous_quantity, 0.0);

            _new_quantity := _previous_quantity + t_row.quantity;

            INSERT INTO sample_stock_transactions(created_by, organization_id, user_id, product_id, allocation_id,
                                                  transaction_type, quantity, previous_quantity, new_quantity)
            VALUES (t_row.approved_by, t_row.organization_id, t_row.user_id, t_row.product_id, t_row.id, 'ALLOCATION',
                    t_row.quantity, _previous_quantity, _new_quantity);
            INSERT INTO sample_stocks (created_by, organization_id, user_id, product_id, quantity)
            VALUES (t_row.approved_by, t_row.organization_id, t_row.user_id, t_row.product_id, _new_quantity)
            ON CONFLICT(user_id, product_id)
                DO UPDATE SET quantity = _new_quantity;
            _counter := _counter + 1;
        END LOOP;
    RETURN _row_count;
END;
$$;

alter function update_user_sample_stock_by_allocation(bigint[]) owner to bizmotion_user;

