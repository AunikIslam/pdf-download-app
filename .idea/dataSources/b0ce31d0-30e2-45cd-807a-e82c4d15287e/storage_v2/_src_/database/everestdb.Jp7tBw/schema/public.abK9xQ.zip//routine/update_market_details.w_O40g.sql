create function update_market_details(p_organization_id bigint) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO market_details(last_timestamp, created_at, organization_id, market_id, market_name, market_code,
                             market_active_status, sales_center_id, price_list_id, market_rank, market_level_id,
                             market_level_name, market_level_rank, market_id_hierarchy_array,
                             market_name_hierarchy_array, market_code_hierarchy_array,
                             market_level_id_hierarchy_array, market_level_name_hierarchy_array,
                             market_level_rank_hierarchy_array, market_name_hierarchy, market_code_hierarchy,
                             market_id_hierarchy, market_level_id_hierarchy, market_level_name_hierarchy,
                             market_level_rank_hierarchy, dfs_seq)
  SELECT now(),
         now(),
         p_organization_id,
         t.market_id,
         t.market_name,
         t.market_code,
         t.market_active_status,
         t.sales_center_id,
         t.price_list_id,
         t.market_rank,
         t.market_level_id,
         t.market_level_name,
         t.market_level_rank,
         t.market_id_hierarchy_array,
         t.market_name_hierarchy_array,
         t.market_code_hierarchy_array,
         t.market_level_id_hierarchy_array,
         t.market_level_name_hierarchy_array,
         t.market_level_rank_hierarchy_array,
         t.market_name_hierarchy,
         t.market_code_hierarchy,
         t.market_id_hierarchy,
         t.market_level_id_hierarchy,
         t.market_level_name_hierarchy,
         t.market_level_rank_hierarchy,
         t.seq2
  FROM (WITH RECURSIVE market_details_view_v3 AS (SELECT m1.id                                                                               AS market_id,
                                                         m1.name                                                                             AS market_name,
                                                         m1.code                                                                             AS market_code,
                                                         m1.sales_center_id                                                                  AS sales_center_id,
                                                         m1.price_list_id                                                                    AS price_list_id,
                                                         m1.is_active                                                                        AS market_active_status,
                                                         1                                                                                   AS market_rank,
                                                         ml1.id                                                                              AS market_level_id,
                                                         ml1.name                                                                            AS market_level_name,
                                                         ml1.level_rank                                                                      AS market_level_rank,
                                                         ARRAY [m1.name]                                                                     AS market_name_hierarchy_array,
                                                         ARRAY [m1.code]                                                                     AS market_code_hierarchy_array,
                                                         ARRAY [m1.id]                                                                       AS market_id_hierarchy_array,
                                                         ARRAY [ml1.id]                                                                      AS market_level_id_hierarchy_array,
                                                         ARRAY [ml1.name]                                                                    AS market_level_name_hierarchy_array,
                                                         ARRAY [ml1.level_rank]                                                              AS market_level_rank_hierarchy_array,
                                                         cast(row_number() over (PARTITION BY m1.parent_id ORDER BY m1.name, m1.id) AS TEXT) AS seq2
                                                  FROM markets m1
                                                         LEFT JOIN market_levels ml1 ON m1.market_level_id = ml1.id
                                                  WHERE (m1.parent_id IS NULL)
                                                    AND m1.organization_id = p_organization_id
                                                  UNION ALL
                                                  SELECT m2.id                                                      AS market_id,
                                                         m2.name                                                    AS market_name,
                                                         m2.code                                                    AS market_code,
                                                         coalesce(m2.sales_center_id, mldv.sales_center_id)         AS sales_center_id,
                                                         coalesce(m2.price_list_id, mldv.price_list_id)             AS price_list_id,
                                                         m2.is_active                                               AS market_active_status,
                                                         (mldv.market_rank + 1)                                     AS market_rank,
                                                         ml2.id                                                     AS market_level_id,
                                                         ml2.name                                                   AS market_level_name,
                                                         ml2.level_rank                                             AS market_level_rank,
                                                         (m2.name || mldv.market_name_hierarchy_array)              AS market_name_hierarchy_array,
                                                         (m2.code || mldv.market_code_hierarchy_array)              AS market_code_hierarchy_array,
                                                         (m2.id || mldv.market_id_hierarchy_array)                  AS market_id_hierarchy_array,
                                                         (ml2.id || mldv.market_level_id_hierarchy_array)           AS market_level_id_hierarchy_array,
                                                         (ml2.name || mldv.market_level_name_hierarchy_array)       AS market_level_name_hierarchy_array,
                                                         (ml2.level_rank || mldv.market_level_rank_hierarchy_array) AS market_level_rank_hierarchy_array,
                                                         mldv.seq2 ||
                                                         lpad(cast(row_number()
                                                                   over (PARTITION BY m2.parent_id ORDER BY m2.name, m2.id) AS TEXT),
                                                              2,
                                                              '0')                                                  AS seq2
                                                  FROM markets m2
                                                         LEFT JOIN market_levels ml2 on m2.market_level_id = ml2.id
                                                         INNER JOIN market_details_view_v3 mldv ON m2.parent_id = mldv.market_id)
        SELECT market_details_view_v3.market_id,
               market_details_view_v3.market_name,
               market_details_view_v3.market_code,
               market_details_view_v3.market_active_status,
               market_details_view_v3.market_rank,
               market_details_view_v3.sales_center_id,
               market_details_view_v3.price_list_id,
               market_details_view_v3.market_level_id,
               market_details_view_v3.market_level_name,
               market_details_view_v3.market_level_rank,
               market_details_view_v3.market_name_hierarchy_array,
               market_details_view_v3.market_code_hierarchy_array,
               market_details_view_v3.market_id_hierarchy_array,
               market_details_view_v3.market_level_id_hierarchy_array,
               market_details_view_v3.market_level_name_hierarchy_array,
               market_details_view_v3.market_level_rank_hierarchy_array,
               array_to_json(market_details_view_v3.market_name_hierarchy_array)     AS market_name_hierarchy,
               array_to_json(market_details_view_v3.market_code_hierarchy_array)     AS market_code_hierarchy,
               array_to_json(market_details_view_v3.market_id_hierarchy_array)       AS market_id_hierarchy,
               array_to_json(market_details_view_v3.market_level_id_hierarchy_array) AS market_level_id_hierarchy,
               array_to_json(
                   market_details_view_v3.market_level_name_hierarchy_array)     AS market_level_name_hierarchy,
               array_to_json(
                   market_details_view_v3.market_level_rank_hierarchy_array)     AS market_level_rank_hierarchy,
               cast(rpad(seq2, 18, '0') AS BIGINT)                                   AS seq2
        FROM market_details_view_v3) t
  ON CONFLICT (market_id)
    DO UPDATE
    SET last_timestamp                    = now(),
        market_name                       = excluded.market_name,
        market_code                       = excluded.market_code,
        market_active_status              = excluded.market_active_status,
        sales_center_id                   = excluded.sales_center_id,
        price_list_id                     = excluded.price_list_id,
        market_rank                       = excluded.market_rank,
        market_level_id                   = excluded.market_level_id,
        market_level_name                 = excluded.market_level_name,
        market_level_rank                 = excluded.market_level_rank,
        market_id_hierarchy_array         = excluded.market_id_hierarchy_array,
        market_name_hierarchy_array       = excluded.market_name_hierarchy_array,
        market_code_hierarchy_array       = excluded.market_code_hierarchy_array,
        market_level_id_hierarchy_array   = excluded.market_level_id_hierarchy_array,
        market_level_name_hierarchy_array = excluded.market_level_name_hierarchy_array,
        market_level_rank_hierarchy_array = excluded.market_level_rank_hierarchy_array,
        market_name_hierarchy             = excluded.market_name_hierarchy,
        market_code_hierarchy             = excluded.market_code_hierarchy,
        market_id_hierarchy               = excluded.market_id_hierarchy,
        market_level_id_hierarchy         = excluded.market_level_id_hierarchy,
        market_level_name_hierarchy       = excluded.market_level_name_hierarchy,
        market_level_rank_hierarchy       = excluded.market_level_rank_hierarchy,
        dfs_seq                           = excluded.dfs_seq;
END;
$$;

alter function update_market_details(bigint) owner to bizmotion_user;

