create materialized view site_view as
WITH site_market_hierarchy AS (SELECT t.site_id,
                                      array_agg(DISTINCT t.hierarchy_id) AS market_id_hierarchy
                               FROM (SELECT mr.site_id,
                                            unnest(mdv.market_id_hierarchy_array) AS hierarchy_id
                                     FROM site_markets mr
                                              LEFT JOIN market_details_view mdv ON mr.market_id = mdv.market_id) t
                               GROUP BY t.site_id)
SELECT s.id,
       s.organization_id                                                                  AS org_id,
       s.is_active                                                                        AS active,
       s.created_by,
       s.is_approved,
       s.approved_by,
       s.code,
       s.name,
       array_agg(dm.id)                                                                   AS site_market_id_list,
       array_agg(m.market_id)                                                             AS market_id_list,
       array_agg(m.market_name)                                                           AS market_name_list,
       array_agg(m.market_code)                                                           AS market_code_list,
       array_agg(m.market_active_status)                                                  AS market_activestatus_list,
       array_agg(m.market_level_id)                                                       AS market_level_id_list,
       array_agg(m.market_level_name)                                                     AS market_level_name_list,
       array_agg(m.market_level_rank)                                                     AS market_level_rank_list,
       array_to_json(array_agg(array_to_json(m.market_id_hierarchy_array)))::text         AS market_id_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_name_hierarchy_array)))::text       AS market_name_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_code_hierarchy_array)))::text       AS market_code_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_id_hierarchy_array)))::text   AS market_level_id_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_name_hierarchy_array)))::text AS market_level_name_hierarchy_list,
       array_to_json(array_agg(array_to_json(m.market_level_rank_hierarchy_array)))::text AS market_level_rank_hierarchy_list,
       smh.market_id_hierarchy                                                            AS hierarchy_id_array
FROM sites s
         LEFT JOIN site_markets dm ON s.id = dm.site_id
         LEFT JOIN market_details_view m ON dm.market_id = m.market_id
         LEFT JOIN site_market_hierarchy smh ON s.id = smh.site_id
GROUP BY s.id, smh.market_id_hierarchy;

alter materialized view site_view owner to bizmotion_user;

create unique index site_view_index
    on site_view (id);

