create function update_product_market_sales_target(p_org_id bigint, p_year integer, p_month integer, p_product_code text, p_market_code text, p_amount double precision, p_quantity double precision) returns void
    language plpgsql
as
$$
BEGIN
    WITH market_products AS
             (
                 SELECT p.product_id AS product_id,
                        p.created_by AS created_by,
                        m.market_id  AS market_id
                 FROM (
                          SELECT p.id         AS product_id,
                                 p.created_by AS created_by
                          FROM products p
                          WHERE p.organization_id = p_org_id
                            AND p.code = p_product_code
                      ) p
                          CROSS JOIN
                      (
                          SELECT unnest(m2.market_id_hierarchy_array) AS market_id
                          FROM markets m
                                   LEFT JOIN market_details m2 ON m2.market_id = m.id
                          WHERE m.organization_id = p_org_id
                            AND m.code = p_market_code
                      ) m
             )
    INSERT
    INTO market_product_sales_target(last_timestamp, created_at, created_by, organization_id, market_id, product_id,
                                     year,
                                     month, target_amount, target_quantity)
    SELECT now(),
           now(),
           mp.created_by,
           p_org_id,
           mp.market_id,
           mp.product_id,
           p_year,
           p_month,
           p_amount,
           p_quantity
    FROM market_products mp
    ON CONFLICT (market_id, product_id, year, month) DO UPDATE
        SET target_amount   = market_product_sales_target.target_amount + excluded.target_amount,
            target_quantity = market_product_sales_target.target_quantity + excluded.target_quantity;
END;
$$;

alter function update_product_market_sales_target(bigint, integer, integer, text, text, double precision, double precision) owner to bizmotion_user;

