create function todo_after_update_doctor_markets() returns trigger
    language plpgsql
as
$$
BEGIN
  if (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') then
    INSERT INTO updated_doctors(doctor_id)
    VALUES (new.doctor_id);
    RETURN new;
  elsif (TG_OP = 'DELETE') then
    INSERT INTO updated_doctors(doctor_id)
    VALUES (old.doctor_id);
    RETURN old;
  END IF;
END;
$$;

alter function todo_after_update_doctor_markets() owner to bizmotion_user;

