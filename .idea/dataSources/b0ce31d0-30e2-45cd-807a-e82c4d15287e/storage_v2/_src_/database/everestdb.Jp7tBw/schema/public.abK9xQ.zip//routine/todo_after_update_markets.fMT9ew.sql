create function todo_after_update_markets() returns trigger
    language plpgsql
as
$$
DECLARE
    _target_doctors BIGINT[];
BEGIN
    SELECT ARRAY(
             SELECT distinct t.doctor_id
             FROM doctor_details_summary t
             WHERE new.id = ANY (t.market_id_hierarchy_array)
               )
    INTO _target_doctors;
    PERFORM update_doctor_details_summary(_target_doctors);
    RETURN new;
END;
$$;

alter function todo_after_update_markets() owner to bizmotion_user;

