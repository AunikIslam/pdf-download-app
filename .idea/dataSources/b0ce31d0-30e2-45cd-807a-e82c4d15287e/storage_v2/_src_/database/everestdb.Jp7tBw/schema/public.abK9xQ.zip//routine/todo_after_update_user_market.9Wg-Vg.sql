create function todo_after_update_user_market() returns trigger
    language plpgsql
as
$$
DECLARE
  _organization_id BIGINT;
BEGIN
  if (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') then
    select m.organization_id
    from markets m
    WHERE m.id = new.market_id
    into _organization_id;
    INSERT INTO updated_market_of_user(org_id, market_id)
    VALUES (_organization_id, new.market_id);
  elsif (TG_OP = 'DELETE') then
    select m.organization_id
    from markets m
    WHERE m.id = old.market_id
    into _organization_id;
    INSERT INTO updated_market_of_user(org_id, market_id)
    VALUES (_organization_id, old.market_id);
  END IF;
  RETURN new;
END;
$$;

alter function todo_after_update_user_market() owner to bizmotion_user;

