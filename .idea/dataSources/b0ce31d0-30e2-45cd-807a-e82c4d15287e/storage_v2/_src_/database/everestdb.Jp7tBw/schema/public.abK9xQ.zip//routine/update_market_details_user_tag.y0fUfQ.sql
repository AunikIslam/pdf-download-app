create function update_market_details_user_tag(p_organization_id bigint, p_market_id bigint) returns void
    language plpgsql
as
$$
BEGIN
    with market_filters(fm_id_list) as (
        select unnest(associated_market_list_including(p_organization_id, TRUE, ARRAY [p_market_id],
                                                       TRUE, TRUE))
    ),
         market_details_2 as (
             select md.id,
                    md.market_id_hierarchy_array
             from market_details md
                      inner join market_filters mf on md.market_id = mf.fm_id_list
         ),
         market_user as (
             select md.id           as id,
                    array_agg(u.id) as userIdList
             from market_details_2 md
                      left join user_markets um on um.market_id = ANY (md.market_id_hierarchy_array)
                      left join users u on um.user_id = u.id
             group by md.id
         )
    update market_details
    set user_id_hierarchy_array = mu.userIdList
    from market_user mu
    where market_details.id = mu.id;
END;
$$;

alter function update_market_details_user_tag(bigint, bigint) owner to bizmotion_user;

