create view user_details_info_view_v2
            (user_id, org_id, is_active, name, code, designation, user_type, product_line_id_list,
             product_line_name_list, assigned_product_line_id_list, assigned_product_line_name_list, role_id, role_name,
             role_rank, has_subordinates, role_market_level_id, role_market_level_name, role_market_level_rank,
             user_market_id_list, user_market_default_list, market_id_list, market_name_list, market_code_list,
             market_active_status_list, market_level_id_list, market_level_name_list, market_level_rank_list,
             market_id_hierarchy_array, market_id_hierarchy_list, market_name_hierarchy_list,
             market_code_hierarchy_list, market_level_id_hierarchy_list, market_level_name_hierarchy_list,
             market_level_rank_hierarchy_list, sales_center_id_list, sales_center_code_list, sales_center_name_list,
             seq)
as
WITH org_product_lines AS (SELECT product_lines.organization_id AS org_id,
                                  array_agg(product_lines.id)   AS pl_id_list,
                                  array_agg(product_lines.name) AS pl_name_list
                           FROM product_lines
                           WHERE product_lines.is_active = true
                           GROUP BY product_lines.organization_id),
     assigned_product_lines AS (SELECT upl.user_id,
                                       array_agg(upl.product_line_id) AS pl_id_list,
                                       array_agg(pl.name)             AS pl_name_list
                                FROM user_product_lines upl
                                         LEFT JOIN product_lines pl ON pl.id = upl.product_line_id AND pl.is_active = true
                                GROUP BY upl.user_id),
     user_role_market_view AS (SELECT u_1.id                                   AS user_id,
                                      ur.id                                    AS userroleid,
                                      ur.name                                  AS userrolename,
                                      ur.rank                                  AS userrolerank,
                                      ur.has_subordinates,
                                      urml.id                                  AS rolemarketlevelid,
                                      urml.name                                AS rolemarketlevelname,
                                      urml.level_rank                          AS rolemarketlevelrank,
                                      array_agg(um.id)                         AS usermarketidlist,
                                      array_agg(um.is_default)                 AS usermarketdefaultlist,
                                      array_agg(m.market_id)                   AS marketidlist,
                                      array_agg(m.market_name)                 AS marketnamelist,
                                      array_agg(m.market_code)                 AS marketcodelist,
                                      array_agg(m.market_active_status)        AS marketactivestatuslist,
                                      array_agg(m.market_level_id)             AS marketlevelidlist,
                                      array_agg(m.market_level_name)           AS marketlevelnamelist,
                                      array_agg(m.market_level_rank)           AS marketlevelranklist,
                                      (SELECT array_agg(t.mhid) AS array_agg
                                       FROM (SELECT DISTINCT unnest(m2.market_id_hierarchy_array) AS mhid
                                             FROM user_markets um2
                                                      LEFT JOIN market_details m2 ON um2.market_id = m2.market_id
                                             WHERE um2.user_id = u_1.id) t)    AS marketidhierarchyarray,
                                      jsonb_agg(m.market_id_hierarchy)         AS marketidhierarchylist,
                                      jsonb_agg(m.market_name_hierarchy)       AS marketnamehierarchylist,
                                      jsonb_agg(m.market_code_hierarchy)       AS marketcodehierarchylist,
                                      jsonb_agg(m.market_level_id_hierarchy)   AS marketlevelidhierarchylist,
                                      jsonb_agg(m.market_level_name_hierarchy) AS marketlevelnamehierarchylist,
                                      jsonb_agg(m.market_level_rank_hierarchy) AS marketlevelrankhierarchylist,
                                      min(m.dfs_seq)                           AS seq
                               FROM user_markets um
                                        RIGHT JOIN users u_1 ON um.user_id = u_1.id
                                        LEFT JOIN user_roles ur ON ur.id = u_1.user_role_id
                                        LEFT JOIN market_levels urml ON urml.id = ur.market_level_id
                                        LEFT JOIN market_details m
                                                  ON um.market_id = m.market_id AND m.market_active_status = true
                               GROUP BY u_1.id, u_1.is_active, u_1.name, u_1.code, u_1.designation, u_1.user_type,
                                        ur.id, ur.name, ur.has_subordinates, urml.id, urml.name, urml.level_rank),
     user_sales_center_view AS (SELECT usc.user_id,
                                       array_agg(sc.id)   AS sales_center_id_list,
                                       array_agg(sc.code) AS sales_center_code_list,
                                       array_agg(sc.name) AS sales_center_name_list
                                FROM user_sales_centers usc
                                         LEFT JOIN sales_centers sc ON sc.id = usc.sales_center_id
                                GROUP BY usc.user_id)
SELECT u.id                              AS user_id,
       u.organization_id                 AS org_id,
       u.is_active,
       u.name,
       u.code,
       u.designation,
       u.user_type,
       opl.pl_id_list                    AS product_line_id_list,
       opl.pl_name_list                  AS product_line_name_list,
       apl.pl_id_list                    AS assigned_product_line_id_list,
       apl.pl_name_list                  AS assigned_product_line_name_list,
       urmv.userroleid                   AS role_id,
       urmv.userrolename                 AS role_name,
       urmv.userrolerank                 AS role_rank,
       urmv.has_subordinates,
       urmv.rolemarketlevelid            AS role_market_level_id,
       urmv.rolemarketlevelname          AS role_market_level_name,
       urmv.rolemarketlevelrank          AS role_market_level_rank,
       urmv.usermarketidlist             AS user_market_id_list,
       urmv.usermarketdefaultlist        AS user_market_default_list,
       urmv.marketidlist                 AS market_id_list,
       urmv.marketnamelist               AS market_name_list,
       urmv.marketcodelist               AS market_code_list,
       urmv.marketactivestatuslist       AS market_active_status_list,
       urmv.marketlevelidlist            AS market_level_id_list,
       urmv.marketlevelnamelist          AS market_level_name_list,
       urmv.marketlevelranklist          AS market_level_rank_list,
       urmv.marketidhierarchyarray       AS market_id_hierarchy_array,
       urmv.marketidhierarchylist        AS market_id_hierarchy_list,
       urmv.marketnamehierarchylist      AS market_name_hierarchy_list,
       urmv.marketcodehierarchylist      AS market_code_hierarchy_list,
       urmv.marketlevelidhierarchylist   AS market_level_id_hierarchy_list,
       urmv.marketlevelnamehierarchylist AS market_level_name_hierarchy_list,
       urmv.marketlevelrankhierarchylist AS market_level_rank_hierarchy_list,
       uscv.sales_center_id_list,
       uscv.sales_center_code_list,
       uscv.sales_center_name_list,
       urmv.seq
FROM users u
         LEFT JOIN org_product_lines opl ON opl.org_id = u.organization_id
         LEFT JOIN assigned_product_lines apl ON apl.user_id = u.id
         LEFT JOIN user_role_market_view urmv ON urmv.user_id = u.id
         LEFT JOIN user_sales_center_view uscv ON uscv.user_id = u.id;

alter table user_details_info_view_v2
    owner to bizmotion_user;

