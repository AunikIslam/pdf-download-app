create function invoice_on_version_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.version <= OLD.version THEN
        RAISE EXCEPTION 'Operation not permitted: version mismatch for invoice : %', NEW.id;
    END IF;

    RETURN NEW;
END;
$$;

alter function invoice_on_version_update() owner to bizmotion_user;

