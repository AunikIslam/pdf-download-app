create function process_update_log_distributor() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_distributor(operation, org_id, distributor_id, old_active, new_active)
        VALUES (TG_OP, NEW.organization_id, NEW.id, new.is_active, new.is_active);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO updated_distributor(operation, org_id, distributor_id, old_active, new_active)
        VALUES (TG_OP, NEW.organization_id, OLD.id, OLD.is_active, new.is_active);
        RETURN NEW;
    END IF;
END;
$$;

alter function process_update_log_distributor() owner to bizmotion_user;

