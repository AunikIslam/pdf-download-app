create function update_log_organization_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO auth.updated_organization(operation, org_id)
        VALUES (TG_OP, NEW.id);
        INSERT INTO updated_organization(operation, org_id)
        VALUES (TG_OP, NEW.id);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO auth.updated_organization (operation, org_id)
        VALUES (TG_OP, OLD.id);
        INSERT INTO updated_organization(operation, org_id)
        VALUES (TG_OP, OLD.id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO auth.updated_organization (operation, org_id)
        VALUES (TG_OP, OLD.id);
        INSERT INTO updated_organization(operation, org_id)
        VALUES (TG_OP, OLD.id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_organization_changes() owner to bizmotion_user;

