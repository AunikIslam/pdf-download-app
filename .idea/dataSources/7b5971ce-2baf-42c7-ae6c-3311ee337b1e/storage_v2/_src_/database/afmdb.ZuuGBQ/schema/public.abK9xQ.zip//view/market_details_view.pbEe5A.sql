create view market_details_view
            (market_id, market_name, market_code, market_active_status, market_rank, market_level_id, market_level_name,
             market_level_rank, market_name_hierarchy_array, market_code_hierarchy_array, market_id_hierarchy_array,
             market_level_id_hierarchy_array, market_level_name_hierarchy_array, market_level_rank_hierarchy_array)
as
WITH RECURSIVE market_details_view(market_id, market_name, market_code, market_active_status, market_rank,
                                   market_level_id, market_level_name, market_level_rank, market_name_hierarchy_array,
                                   market_code_hierarchy_array, market_id_hierarchy_array,
                                   market_level_id_hierarchy_array, market_level_name_hierarchy_array,
                                   market_level_rank_hierarchy_array) AS (SELECT m1.id                  AS market_id,
                                                                                 m1.name                AS market_name,
                                                                                 m1.code                AS market_code,
                                                                                 m1.is_active           AS market_active_status,
                                                                                 1                      AS market_rank,
                                                                                 ml1.id                 AS market_level_id,
                                                                                 ml1.name               AS market_level_name,
                                                                                 ml1.level_rank         AS market_level_rank,
                                                                                 ARRAY [m1.name]        AS market_name_hierarchy_array,
                                                                                 ARRAY [m1.code]        AS market_code_hierarchy_array,
                                                                                 ARRAY [m1.id]          AS market_id_hierarchy_array,
                                                                                 ARRAY [ml1.id]         AS market_level_id_hierarchy_array,
                                                                                 ARRAY [ml1.name]       AS market_level_name_hierarchy_array,
                                                                                 ARRAY [ml1.level_rank] AS market_level_rank_hierarchy_array
                                                                          FROM markets m1
                                                                                   LEFT JOIN market_levels ml1 ON m1.market_level_id = ml1.id
                                                                          WHERE m1.parent_id IS NULL
                                                                          UNION ALL
                                                                          SELECT m2.id                                                    AS market_id,
                                                                                 m2.name                                                  AS market_name,
                                                                                 m2.code                                                  AS market_code,
                                                                                 m2.is_active                                             AS market_active_status,
                                                                                 mldv.market_rank + 1                                     AS market_rank,
                                                                                 ml2.id                                                   AS market_level_id,
                                                                                 ml2.name                                                 AS market_level_name,
                                                                                 ml2.level_rank                                           AS market_level_rank,
                                                                                 m2.name || mldv.market_name_hierarchy_array              AS market_name_hierarchy_array,
                                                                                 m2.code || mldv.market_code_hierarchy_array              AS market_code_hierarchy_array,
                                                                                 m2.id || mldv.market_id_hierarchy_array                  AS market_id_hierarchy_array,
                                                                                 ml2.id || mldv.market_level_id_hierarchy_array           AS market_level_id_hierarchy_array,
                                                                                 ml2.name || mldv.market_level_name_hierarchy_array       AS market_level_name_hierarchy_array,
                                                                                 ml2.level_rank || mldv.market_level_rank_hierarchy_array AS market_level_rank_hierarchy_array
                                                                          FROM markets m2
                                                                                   LEFT JOIN market_levels ml2 ON m2.market_level_id = ml2.id
                                                                                   JOIN market_details_view mldv ON m2.parent_id = mldv.market_id)
SELECT market_id,
       market_name,
       market_code,
       market_active_status,
       market_rank,
       market_level_id,
       market_level_name,
       market_level_rank,
       market_name_hierarchy_array,
       market_code_hierarchy_array,
       market_id_hierarchy_array,
       market_level_id_hierarchy_array,
       market_level_name_hierarchy_array,
       market_level_rank_hierarchy_array
FROM market_details_view;

alter table market_details_view
    owner to bizmotion_user;

