create function user_info_change_trigger_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO afm.master_data_update_queue(operation, target_type, ref_id, try_count)
        VALUES (TG_OP, 'USER', NEW.intemployeeid, 0)
        ON CONFLICT (target_type, ref_id) DO UPDATE SET delay = 0;
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO afm.master_data_update_queue(operation, target_type, ref_id, try_count)
        VALUES (TG_OP, 'USER', OLD.intemployeeid, 0)
        ON CONFLICT (target_type, ref_id) DO UPDATE SET delay = 0;
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO afm.master_data_update_queue(operation, target_type, ref_id, try_count)
        VALUES (TG_OP, 'USER', OLD.intemployeeid, 0)
        ON CONFLICT (target_type, ref_id) DO UPDATE SET delay = 0;
        RETURN OLD;
    END IF;
END;
$$;

alter function user_info_change_trigger_func() owner to bizmotion_user;

