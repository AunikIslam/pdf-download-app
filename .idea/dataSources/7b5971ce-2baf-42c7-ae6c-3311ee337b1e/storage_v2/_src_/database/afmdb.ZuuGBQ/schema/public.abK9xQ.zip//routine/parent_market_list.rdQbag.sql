create function parent_market_list(p_organization_id bigint, p_market_assigned boolean, assigned_market_id_list bigint[]) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_list BIGINT [];
BEGIN
    SELECT ARRAY(
      SELECT DISTINCT (t.market_id)
      FROM
          (WITH RECURSIVE market_heirarchy(market_id, market_name, market_parent_id, market_sequence) AS (
              SELECT
                  m.id        AS market_id,
                  m.name      AS market_name,
                  m.parent_id AS market_parent_id,
                  1           AS market_sequence
              FROM
                  markets m
              WHERE
                  m.organization_id = p_organization_id
                  AND m.is_deleted = FALSE
                  AND CASE WHEN p_market_assigned = TRUE
                      THEN m.id = ANY (assigned_market_id_list)
                      ELSE m.id IS NULL END
              UNION ALL
              SELECT
                  m.id                   AS market_id,
                  m.name                 AS market_name,
                  m.parent_id            AS market_parent_id,
                  mh.market_sequence + 1 AS market_sequence
              FROM
                  markets m
                  INNER JOIN market_heirarchy mh ON m.id = mh.market_parent_id
              WHERE
                  m.is_deleted = FALSE
          )
          SELECT mh.market_id
          FROM
              market_heirarchy mh) AS t
      WHERE NOT (t.market_id = ANY (assigned_market_id_list)))
    INTO market_list;
    RETURN market_list;
END
$$;

alter function parent_market_list(bigint, boolean, bigint[]) owner to bizmotion_user;

