create function update_db_stock_by_distributor_product_return(return_id_list bigint[]) returns bigint
    language plpgsql
as
$$
DECLARE
    _previous_quantity DOUBLE PRECISION;
    _new_quantity      DOUBLE PRECISION;
    _row_count         BIGINT;
    _counter           BIGINT;
    _transaction_type  TEXT;
    t_row              distributor_returned_products%rowtype;

BEGIN
    _counter := 1;
    FOR t_row IN
        SELECT *
        FROM distributor_returned_products
        WHERE id = ANY (ARRAY [return_id_list])
        LOOP
            SELECT quantity
            FROM distributor_stocks
            WHERE distributor_id = t_row.distributor_id
              AND product_id = t_row.product_id
            INTO _previous_quantity;
            _previous_quantity = coalesce(_previous_quantity, 0.0);

            _new_quantity := _previous_quantity - 1;
            _transaction_type := 'RETURNED_BY_DISTRIBUTOR';

            INSERT INTO distributor_stock_transactions (created_by, created_at, organization_id, distributor_id,
                                                        product_id,
                                                        previous_quantity, quantity, new_quantity, transaction_type,
                                                        distributor_challan_id, customer_challan_id, customer_return_id,
                                                        distributor_return_id, transfer_id, transaction_time)
            VALUES (t_row.approved_by, now(), t_row.organization_id, t_row.distributor_id, t_row.product_id,
                    _previous_quantity, 1.0, _new_quantity, _transaction_type, null, null, null, t_row.id, null, now());
            INSERT INTO distributor_stocks (created_by, organization_id, distributor_id, product_id, quantity)
            VALUES (t_row.approved_by, t_row.organization_id, t_row.distributor_id, t_row.product_id, _new_quantity)
            ON CONFLICT(distributor_id, product_id)
                DO UPDATE SET quantity = _new_quantity;
            _counter := _counter + 1;
        END LOOP;
    RETURN _row_count;
END;
$$;

alter function update_db_stock_by_distributor_product_return(bigint[]) owner to bizmotion_user;

