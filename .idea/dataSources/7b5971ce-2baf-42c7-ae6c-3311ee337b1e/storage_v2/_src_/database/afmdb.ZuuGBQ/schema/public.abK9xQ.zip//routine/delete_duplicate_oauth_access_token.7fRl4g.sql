create function delete_duplicate_oauth_access_token() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM oauth_access_token WHERE authentication_id = NEW.authentication_id;
    RETURN NEW;
END;
$$;

alter function delete_duplicate_oauth_access_token() owner to bizmotion_user;

