create function assigned_market_list_of_distributor(p_organization_id bigint, p_distributor_id bigint) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_list BIGINT [];
BEGIN
    SELECT array(
      SELECT dm.market_id
      FROM
          distributor_markets dm
          LEFT JOIN markets m ON dm.market_id = m.id
      WHERE
          m.is_active = TRUE
          AND m.organization_id = p_organization_id
          AND dm.distributor_id = p_distributor_id
    )
    INTO market_list;
    RETURN market_list;
END;
$$;

alter function assigned_market_list_of_distributor(bigint, bigint) owner to bizmotion_user;

