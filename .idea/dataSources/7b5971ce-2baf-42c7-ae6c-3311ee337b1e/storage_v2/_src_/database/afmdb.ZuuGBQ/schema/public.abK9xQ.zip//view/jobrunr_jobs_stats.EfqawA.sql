create view jobrunr_jobs_stats
            (total, scheduled, enqueued, processing, failed, succeeded, alltimesucceeded, deleted,
             nbrofbackgroundjobservers, nbrofrecurringjobs)
as
WITH job_stat_results AS (SELECT jobrunr_jobs.state,
                                 count(*) AS count
                          FROM jobrunr_jobs
                          GROUP BY ROLLUP (jobrunr_jobs.state))
SELECT COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state IS NULL), 0::bigint)                        AS total,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state::text = 'SCHEDULED'::text), 0::bigint)      AS scheduled,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state::text = 'ENQUEUED'::text), 0::bigint)       AS enqueued,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state::text = 'PROCESSING'::text), 0::bigint)     AS processing,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state::text = 'FAILED'::text), 0::bigint)         AS failed,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state::text = 'SUCCEEDED'::text), 0::bigint)      AS succeeded,
       COALESCE((SELECT jm.value::character(10)::numeric(10, 0) AS value
                 FROM jobrunr_metadata jm
                 WHERE jm.id::text = 'succeeded-jobs-counter-cluster'::text), 0::numeric) AS alltimesucceeded,
       COALESCE((SELECT job_stat_results.count
                 FROM job_stat_results
                 WHERE job_stat_results.state::text = 'DELETED'::text), 0::bigint)        AS deleted,
       (SELECT count(*) AS count
        FROM jobrunr_backgroundjobservers)                                                AS nbrofbackgroundjobservers,
       (SELECT count(*) AS count
        FROM jobrunr_recurring_jobs)                                                      AS nbrofrecurringjobs;

alter table jobrunr_jobs_stats
    owner to bizmotion_user;

