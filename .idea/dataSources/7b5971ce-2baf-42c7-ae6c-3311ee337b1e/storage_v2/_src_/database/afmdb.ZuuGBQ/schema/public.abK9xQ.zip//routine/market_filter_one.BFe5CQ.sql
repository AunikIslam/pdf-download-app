create function market_filter_one(organization_id bigint, user_id bigint, has_market_level boolean, filter_by_market_id integer, market_id_filter bigint[]) returns hstore
    language plpgsql
as
$$
DECLARE
    _mmap hstore;
BEGIN
    WITH market_filters(um_id_list, fm_id_list) AS
             (VALUES (accessible_markets_of_user(organization_id, user_id, has_market_level, true),
                      CASE
                          WHEN filter_by_market_id = 0
                              THEN market_id_filter
                          WHEN filter_by_market_id = 1
                              THEN associated_market_list_including(organization_id, TRUE, market_id_filter,
                                                                    TRUE, TRUE)
                          ELSE market_id_filter
                          END))
    SELECT hstore(array_agg(cast(mf.market_id AS TEXT)), array_agg(mf.val)) mmap
    FROM (SELECT unnest(mf.fm_id) AS market_id,
                 't'              AS val
          FROM (SELECT CASE
                           WHEN filter_by_market_id = 0 THEN mf.um_id_list
                           ELSE mf.fm_id_list END AS fm_id
                FROM market_filters mf) mf) mf
    INTO _mmap;
    RETURN _mmap;
END;
$$;

alter function market_filter_one(bigint, bigint, boolean, integer, bigint[]) owner to bizmotion_user;

