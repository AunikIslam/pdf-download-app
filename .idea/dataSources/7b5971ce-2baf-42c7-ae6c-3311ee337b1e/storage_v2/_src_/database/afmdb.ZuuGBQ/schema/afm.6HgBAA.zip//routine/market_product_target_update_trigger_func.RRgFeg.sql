create function market_product_target_update_trigger_func() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO afm.market_product_target_updates(operation, ref_id, try_count)
        VALUES (TG_OP, NEW.id, 0)
        ON CONFLICT (ref_id) DO UPDATE SET delay = 0, modified_at = now(), try_after = now();
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO afm.market_product_target_updates(operation, ref_id, try_count)
        VALUES (TG_OP, NEW.id, 0)
        ON CONFLICT (ref_id) DO UPDATE SET delay = 0, modified_at = now(), try_after = now();
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO afm.market_product_target_updates(operation, ref_id, try_count)
        VALUES (TG_OP, OLD.id, 0)
        ON CONFLICT (ref_id) DO UPDATE SET delay = 0, modified_at = now(), try_after = now();
        RETURN OLD;
    END IF;
END;
$$;

alter function market_product_target_update_trigger_func() owner to bizmotion_user;

