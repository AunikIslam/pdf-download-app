create function presentable_markets_for_user(p_organization_id bigint, p_user_id bigint, filter_by_active_market boolean, active_market_filter boolean) returns bigint[]
    language plpgsql
as
$$
DECLARE
    _assigned_market_list    BIGINT [];
    _accessible_market_list  BIGINT [];
    _parent_market_list      BIGINT [];
    _presentable_market_list BIGINT [];
    _has_assigned_market     BOOLEAN;
    _enable_active_filter    BOOLEAN;
    _distributor_id_of_user  BIGINT;
BEGIN
    IF filter_by_active_market = TRUE AND active_market_filter = TRUE
    THEN _enable_active_filter = TRUE;
    ELSE _enable_active_filter = FALSE;
    END IF;
    _distributor_id_of_user = (SELECT usr.distributor_id
                               FROM users usr
                               WHERE usr.id = p_user_id);
    IF _distributor_id_of_user ISNULL
    THEN
        _assigned_market_list = assigned_market_list_of_user(p_organization_id, p_user_id);
    ELSE
        _assigned_market_list = assigned_market_list_of_distributor(p_organization_id, _distributor_id_of_user);
        IF array_length(_assigned_market_list, 1) = 0
        THEN _assigned_market_list = _assigned_market_list || -1;
        END IF;
    END IF;

    _has_assigned_market = array_length(_assigned_market_list, 1) > 0;
    _accessible_market_list = associated_market_list_including(p_organization_id, _has_assigned_market,
                                                               _assigned_market_list, _enable_active_filter,
                                                               active_market_filter);
    _parent_market_list = parent_market_list(p_organization_id, _has_assigned_market, _assigned_market_list);
    _presentable_market_list = _parent_market_list || _accessible_market_list;
    RETURN _presentable_market_list;
END
$$;

alter function presentable_markets_for_user(bigint, bigint, boolean, boolean) owner to bizmotion_user;

