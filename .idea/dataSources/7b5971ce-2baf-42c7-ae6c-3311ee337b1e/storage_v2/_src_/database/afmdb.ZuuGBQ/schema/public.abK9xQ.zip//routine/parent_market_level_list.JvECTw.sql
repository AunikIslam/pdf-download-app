create function parent_market_level_list(p_organization_id bigint, p_market_level_assigned boolean, p_assigned_market_level_id bigint) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_level_list BIGINT [];
BEGIN
    SELECT ARRAY(
      SELECT DISTINCT (t.market_level_id)
      FROM
          (WITH RECURSIVE market_level_heirarchy(market_level_id, market_level_name, market_level_parent_id, market_level_sequence) AS (
              SELECT
                  ml.id        AS market_level_id,
                  ml.name      AS market_level_name,
                  ml.parent_id AS market_level_parent_id,
                  1           AS market_level_sequence
              FROM
                  market_levels ml
              WHERE
                  ml.organization_id = p_organization_id
                  AND ml.is_deleted = FALSE
                  AND CASE WHEN p_market_level_assigned = TRUE
                      THEN ml.id = p_assigned_market_level_id
                      ELSE ml.id IS NULL END
              UNION ALL
              SELECT
                  ml.id                   AS market_level_id,
                  ml.name                 AS market_level_name,
                  ml.parent_id            AS market_level_parent_id,
                  mh.market_level_sequence + 1 AS market_level_sequence
              FROM
                  market_levels ml
                  INNER JOIN market_level_heirarchy mh ON ml.id = mh.market_level_parent_id
              WHERE
                  ml.is_deleted = FALSE
          )
          SELECT mh.market_level_id
          FROM
              market_level_heirarchy mh) AS t
      WHERE NOT (t.market_level_id = p_assigned_market_level_id))
    INTO market_level_list;
    RETURN market_level_list;
END
$$;

alter function parent_market_level_list(bigint, boolean, bigint) owner to bizmotion_user;

