create function accessible_markets_of_distributor(p_organization_id bigint, p_distributor_id bigint, p_actives_only boolean) returns bigint[]
    language plpgsql
as
$$
DECLARE
    _assigned_market_list   BIGINT [];
    _accessible_market_list BIGINT [];
BEGIN
    _assigned_market_list = assigned_market_list_of_distributor(p_organization_id, p_distributor_id);
    _accessible_market_list = associated_market_list_including(p_organization_id, TRUE, _assigned_market_list, p_actives_only,
                                                               TRUE);
    RETURN _accessible_market_list;
END
$$;

alter function accessible_markets_of_distributor(bigint, bigint, boolean) owner to bizmotion_user;

