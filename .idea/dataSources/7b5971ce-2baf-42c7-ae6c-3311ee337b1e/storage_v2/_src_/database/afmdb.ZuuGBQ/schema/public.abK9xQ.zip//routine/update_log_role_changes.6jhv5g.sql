create function update_log_role_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO auth.updated_role(operation, role_id)
        VALUES (TG_OP, NEW.id);
        INSERT INTO updated_role(operation, org_id, role_id)
        VALUES (TG_OP, NEW.organization_id, NEW.id);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO auth.updated_role (operation, role_id)
        VALUES (TG_OP, OLD.id);
        INSERT INTO updated_role (operation, org_id, role_id)
        VALUES (TG_OP, OLD.organization_id, OLD.id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO auth.updated_role (operation, role_id)
        VALUES (TG_OP, OLD.id);
        INSERT INTO updated_role (operation, org_id, role_id)
        VALUES (TG_OP, OLD.organization_id, OLD.id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_role_changes() owner to bizmotion_user;

