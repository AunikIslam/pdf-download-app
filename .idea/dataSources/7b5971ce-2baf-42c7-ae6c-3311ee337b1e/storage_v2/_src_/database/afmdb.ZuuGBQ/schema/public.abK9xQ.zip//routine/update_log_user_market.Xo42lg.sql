create function update_log_user_market() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_user_market(operation, user_id, market_id)
        VALUES (TG_OP, NEW.user_id, NEW.market_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_user_market(operation, user_id, market_id)
        VALUES (TG_OP, OLD.user_id, OLD.market_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_user_market() owner to bizmotion_user;

