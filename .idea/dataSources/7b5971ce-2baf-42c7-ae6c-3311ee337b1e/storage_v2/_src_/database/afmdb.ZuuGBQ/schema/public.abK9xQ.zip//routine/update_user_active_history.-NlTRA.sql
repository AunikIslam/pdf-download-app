create function update_user_active_history() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'UPDATE') THEN
        IF (NEW.is_active <> OLD.is_active) THEN
            IF (NEW.is_active = TRUE) THEN
                INSERT INTO user_active_history(created_by, organization_id, user_id, active_from, active_from_date, active_by)
                VALUES (NEW.updated_by, new.organization_id, new.ID, now(), now(), NEW.updated_by);
            ELSE
                UPDATE user_active_history
                SET active_till = now(),
                    active_till_date = now(),
                    inactive_by = NEW.updated_by
                WHERE id = (SELECT t.id
                            FROM (SELECT h.id                                    AS id
                                       , row_number() over (ORDER BY h.id DESC ) AS rn
                                  FROM user_active_history h
                                  WHERE h.user_id = NEW.id) t
                            WHERE t.rn = 1);
            END IF;
        END IF;
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO user_active_history(created_by, organization_id, user_id, active_from, active_from_date, active_by)
        VALUES (NEW.created_by, new.organization_id, new.ID, now(), now(), NEW.created_by);
        RETURN NEW;
    END IF;
END;
$$;

alter function update_user_active_history() owner to bizmotion_user;

