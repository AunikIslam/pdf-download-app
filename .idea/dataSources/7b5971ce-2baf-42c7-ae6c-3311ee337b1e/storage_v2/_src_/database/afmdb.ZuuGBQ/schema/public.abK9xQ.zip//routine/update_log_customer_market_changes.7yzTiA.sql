create function update_log_customer_market_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_customer_market(operation, retailer_id, market_id)
        VALUES (TG_OP, NEW.customer_id, NEW.market_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_customer_market(operation, retailer_id, market_id)
        VALUES (TG_OP, old.customer_id, old.market_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_customer_market_changes() owner to bizmotion_user;

