create function associated_market_list_including(p_organization_id bigint, p_market_assigned boolean, p_market_id_list bigint[], filter_by_active_market boolean, active_market_filter boolean) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_list BIGINT [];
BEGIN
    SELECT ARRAY(
      SELECT t.market_id
      FROM
          (WITH RECURSIVE associated_markets(market_id, market_name, market_parent_id, market_is_active, market_is_deleted, rank) AS (
              SELECT
                  m.id         AS market_id,
                  m.name       AS market_name,
                  m.parent_id  AS market_parent_id,
                  m.is_active  AS market_is_active,
                  m.is_deleted AS market_is_deleted,
                  1            AS rank
              FROM
                  markets m
              WHERE
                  m.organization_id = p_organization_id
                  AND m.is_deleted = FALSE
                  AND m.is_active = TRUE
                  AND CASE WHEN p_market_assigned = TRUE
                      THEN m.id = ANY ( p_market_id_list )
                      ELSE m.parent_id IS NULL END
              UNION ALL
              SELECT
                  m2.id         AS market_id,
                  m2.name       AS market_name,
                  m2.parent_id  AS market_parent_id,
                  m2.is_active  AS market_is_active,
                  m2.is_deleted AS market_is_deleted,
                  am.rank + 1   AS rank
              FROM
                  markets m2, associated_markets am
              WHERE
                  m2.parent_id = am.market_id
          )
          SELECT am.market_id, am.market_name, am.market_is_active, am.market_is_deleted
          FROM
              associated_markets am
          WHERE
              am.market_is_deleted = FALSE
              AND (filter_by_active_market = FALSE OR am.market_is_active = active_market_filter)) AS t)
    INTO market_list;
    RETURN market_list;
END
$$;

alter function associated_market_list_including(bigint, boolean, bigint[], boolean, boolean) owner to bizmotion_user;

