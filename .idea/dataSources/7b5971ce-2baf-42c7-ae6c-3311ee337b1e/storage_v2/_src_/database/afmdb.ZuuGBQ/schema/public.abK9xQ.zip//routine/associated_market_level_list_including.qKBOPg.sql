create function associated_market_level_list_including(p_organization_id bigint, p_market_level_assigned boolean, p_market_level_id bigint) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_level_list BIGINT [];
BEGIN
    SELECT ARRAY(
      SELECT t.market_level_id
      FROM
          (WITH RECURSIVE associated_market_levels(market_level_id, market_level_name, market_level_parent_id, level_rank) AS (
              SELECT
                  ml.id        AS market_level_id,
                  ml.name      AS market_level_name,
                  ml.parent_id AS market_level_parent_id,
                  1            AS level_rank
              FROM
                  market_levels ml
              WHERE
                  ml.organization_id = p_organization_id
                  AND ml.is_deleted = FALSE
                  AND ml.is_active = TRUE
                  AND CASE WHEN p_market_level_assigned = TRUE
                      THEN ml.id = p_market_level_id
                      ELSE ml.parent_id IS NULL END
              UNION ALL
              SELECT
                  ml.id        AS market_id,
                  ml.name      AS market_name,
                  ml.parent_id AS market_parent_id,
                  aml.level_rank + 1 AS level_rank
              FROM
                  market_levels ml, associated_market_levels aml
              WHERE
                  ml.parent_id = aml.market_level_id
                  AND ml.is_deleted = FALSE
                  AND ml.is_active = TRUE
          )
          SELECT aml.market_level_id
          FROM
              associated_market_levels aml) AS t)
    INTO market_level_list;
    RETURN market_level_list;
END
$$;

alter function associated_market_level_list_including(bigint, boolean, bigint) owner to bizmotion_user;

