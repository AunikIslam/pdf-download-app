create function update_log_org_authority_remove() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO auth.removed_authority_of_org (operation, org_id)
        VALUES (TG_OP, OLD.organization_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_org_authority_remove() owner to bizmotion_user;

