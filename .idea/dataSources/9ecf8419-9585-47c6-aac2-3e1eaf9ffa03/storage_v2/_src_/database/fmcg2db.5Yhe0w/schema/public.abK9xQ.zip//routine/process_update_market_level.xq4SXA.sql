create function process_update_market_level() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_market_level(operation, org_id, level_id)
        VALUES (TG_OP, NEW.organization_id, NEW.id);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO updated_market_level(operation, org_id, level_id)
        VALUES (TG_OP, OLD.organization_id, OLD.id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_market_level(operation, org_id, level_id)
        VALUES (TG_OP, OLD.organization_id, OLD.id);
        RETURN OLD;
    END IF;
END;
$$;

alter function process_update_market_level() owner to bizmotion_user;

