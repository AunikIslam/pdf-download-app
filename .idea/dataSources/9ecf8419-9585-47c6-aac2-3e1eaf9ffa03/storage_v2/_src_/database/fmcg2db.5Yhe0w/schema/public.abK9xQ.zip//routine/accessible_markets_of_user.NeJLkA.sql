create function accessible_markets_of_user(p_organization_id bigint, p_user_id bigint, p_has_market_level boolean, active_markets_only boolean) returns bigint[]
    language plpgsql
as
$$
DECLARE
    _assigned_market_list   BIGINT[];
    _accessible_market_list BIGINT[];
BEGIN
    _assigned_market_list = assigned_market_list_of_user(p_organization_id, p_user_id);
    _accessible_market_list = associated_market_list_including(p_organization_id, p_has_market_level,
                                                               _assigned_market_list, active_markets_only, TRUE);
    RETURN _accessible_market_list;
END
$$;

alter function accessible_markets_of_user(bigint, bigint, boolean, boolean) owner to bizmotion_user;

