create function presentable_market_levels_for_user(p_organization_id bigint, p_market_level_assigned boolean, p_assigned_market_level_id bigint) returns bigint[]
    language plpgsql
as
$$
DECLARE
    _parent_market_level_list      BIGINT [];
    _presentable_market_level_list BIGINT [];
BEGIN
    _parent_market_level_list = parent_market_level_list(p_organization_id, p_market_level_assigned, p_assigned_market_level_id);
    _presentable_market_level_list = _parent_market_level_list || associated_market_level_list_including(p_organization_id, p_market_level_assigned, p_assigned_market_level_id);
    RETURN _presentable_market_level_list;
END
$$;

alter function presentable_market_levels_for_user(bigint, boolean, bigint) owner to bizmotion_user;

