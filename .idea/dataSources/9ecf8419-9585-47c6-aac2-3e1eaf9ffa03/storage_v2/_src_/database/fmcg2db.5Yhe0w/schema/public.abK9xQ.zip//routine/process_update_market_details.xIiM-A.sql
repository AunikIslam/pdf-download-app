create function process_update_market_details() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO public.updated_market(operation, org_id, market_id, old_active, new_active, old_parent, new_parent)
        VALUES (TG_OP, NEW.organization_id, NEW.id, new.is_active, new.is_active, new.parent_id, new.parent_id);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO public.updated_market(operation, org_id, market_id, old_active, new_active, old_parent, new_parent)
        VALUES (TG_OP, NEW.organization_id, OLD.id, OLD.is_active, new.is_active, OLD.parent_id, new.parent_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO public.updated_market(operation, org_id, market_id, old_active, new_active, old_parent, new_parent)
        VALUES (TG_OP, OLD.organization_id, OLD.id, OLD.is_active, OLD.is_active, OLD.parent_id, OLD.parent_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function process_update_market_details() owner to bizmotion_user;

