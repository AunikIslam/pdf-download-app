create function get_subordinates(p_user_id bigint, filtrby_active boolean, active_filter boolean) returns bigint[]
    language plpgsql
as
$$
DECLARE
    _assigned_market_id_list        BIGINT [];
    _sub_market_id_list             BIGINT [];
    _user_market_levle_id           BIGINT;
    _subordinate_user_id_list       BIGINT [];
    _assigned_market_id             BIGINT;
    _sub_market_id                  BIGINT;
    _subordinate_user_id_list_local BIGINT [];
BEGIN
    SELECT
        DISTINCT
        (tur.market_level_id),
        ARRAY_AGG(tum.market_id)
    INTO _user_market_levle_id, _assigned_market_id_list
    FROM user_markets tum
        LEFT JOIN users tu ON tum.user_id = tu.id
        LEFT JOIN user_roles tur ON tu.user_role_id = tur.id
        LEFT JOIN markets tm ON tum.market_id = tm.id
    WHERE tu.id = p_user_id
          AND tm.is_active = TRUE
    GROUP BY tur.market_level_id;

    SELECT array_agg(tum.user_id)
    INTO _subordinate_user_id_list
    FROM user_markets tum
        LEFT JOIN users tu ON tum.user_id = tu.id
        LEFT JOIN user_roles tur ON tu.user_role_id = tur.id
    WHERE tum.market_id = ANY (_assigned_market_id_list)
          AND tur.market_level_id > _user_market_levle_id
          AND (filtrby_active = FALSE OR tu.is_active = active_filter);

    WHILE array_length(_assigned_market_id_list, 1) > 0
    LOOP
        _assigned_market_id = _assigned_market_id_list [1];
        SELECT array_agg(tm.id)
        INTO _sub_market_id_list
        FROM markets tm
        WHERE
            tm.parent_id = _assigned_market_id
            AND tm.is_active = TRUE;

        _assigned_market_id_list = array_remove(_assigned_market_id_list, _assigned_market_id);

        IF (_sub_market_id_list ISNULL) = FALSE
        THEN
            FOREACH _sub_market_id IN ARRAY _sub_market_id_list
            LOOP
                SELECT array_agg(tum.user_id)
                INTO _subordinate_user_id_list_local
                FROM user_markets tum
                    LEFT JOIN users tu ON tum.user_id = tu.id
                    LEFT JOIN user_roles tur ON tu.user_role_id = tur.id
                WHERE tum.market_id = _sub_market_id
                      AND tur.market_level_id > _user_market_levle_id
                      AND (filtrby_active = FALSE OR tu.is_active = active_filter);
                RAISE NOTICE '% %', _sub_market_id, _subordinate_user_id_list_local ISNULL;
                IF _subordinate_user_id_list_local ISNULL
                THEN _assigned_market_id_list = _assigned_market_id_list || _sub_market_id;
                ELSE _subordinate_user_id_list = _subordinate_user_id_list || _subordinate_user_id_list_local;
                END IF;
            END LOOP;
        END IF;
    END LOOP;
    RETURN _subordinate_user_id_list;
END;

$$;

alter function get_subordinates(bigint, boolean, boolean) owner to bizmotion_user;

