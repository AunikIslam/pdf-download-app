create function update_log_org_settings_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO auth.updated_settings_of_organization(operation, org_id)
        VALUES (TG_OP, NEW.organization_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO auth.updated_settings_of_organization (operation, org_id)
        VALUES (TG_OP, OLD.organization_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_org_settings_changes() owner to bizmotion_user;

