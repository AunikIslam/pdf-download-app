create function update_log_distributor_product_lines_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_distributor_product_lines(operation, distributor_id, pl_id)
        VALUES (TG_OP, NEW.distributor_id, NEW.product_line_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_distributor_product_lines(operation, distributor_id, pl_id)
        VALUES (TG_OP, OLD.distributor_id, OLD.product_line_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_distributor_product_lines_changes() owner to bizmotion_user;

