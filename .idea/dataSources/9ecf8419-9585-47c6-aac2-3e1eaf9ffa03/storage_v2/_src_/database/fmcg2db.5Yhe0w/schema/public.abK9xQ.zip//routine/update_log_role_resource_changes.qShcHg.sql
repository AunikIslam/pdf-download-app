create function update_log_role_resource_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO auth.updated_authority_of_role(operation, role_id)
        VALUES (TG_OP, NEW.user_role_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO auth.updated_authority_of_role (operation, role_id)
        VALUES (TG_OP, OLD.user_role_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_role_resource_changes() owner to bizmotion_user;

