create function assigned_market_list_of_customer(p_organization_id bigint, p_customer_id bigint) returns bigint[]
    language plpgsql
as
$$
DECLARE
    market_list BIGINT [];
BEGIN
    SELECT array(
      SELECT cm.market_id
      FROM
          customer_markets cm
          LEFT JOIN markets m ON cm.market_id = m.id
      WHERE
          m.is_active = TRUE
          AND m.organization_id = p_organization_id
          AND cm.customer_id = p_customer_id
    )
    INTO market_list;
    RETURN market_list;
END;
$$;

alter function assigned_market_list_of_customer(bigint, bigint) owner to bizmotion_user;

