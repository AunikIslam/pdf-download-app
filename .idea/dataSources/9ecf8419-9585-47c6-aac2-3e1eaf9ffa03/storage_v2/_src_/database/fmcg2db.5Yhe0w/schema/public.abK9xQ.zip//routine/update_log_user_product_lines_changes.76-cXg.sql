create function update_log_user_product_lines_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_user_product_lines(operation, user_id, pl_id)
        VALUES (TG_OP, NEW.user_id, NEW.product_line_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_user_product_lines(operation, user_id, pl_id)
        VALUES (TG_OP, OLD.user_id, OLD.product_line_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_user_product_lines_changes() owner to bizmotion_user;

