create function update_log_product_lines_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_product_lines(operation, org_id, pl_id)
        VALUES (TG_OP, NEW.organization_id, NEW.id);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO updated_product_lines(operation, org_id, pl_id)
        VALUES (TG_OP, OLD.organization_id, OLD.id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_product_lines(operation, org_id, pl_id)
        VALUES (TG_OP, OLD.organization_id, OLD.id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_product_lines_changes() owner to bizmotion_user;

