create function update_log_distributor_market() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_distributor_market(operation, distributor_id, market_id)
        VALUES (TG_OP, NEW.distributor_id, NEW.market_id);
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        INSERT INTO updated_distributor_market(operation, distributor_id, market_id)
        VALUES (TG_OP, OLD.distributor_id, OLD.market_id);
        RETURN OLD;
    END IF;
END;
$$;

alter function update_log_distributor_market() owner to bizmotion_user;

