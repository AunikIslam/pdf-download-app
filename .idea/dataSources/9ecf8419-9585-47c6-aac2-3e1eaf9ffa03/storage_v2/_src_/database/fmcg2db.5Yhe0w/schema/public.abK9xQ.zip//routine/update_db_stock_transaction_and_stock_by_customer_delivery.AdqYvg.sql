create function update_db_stock_transaction_and_stock_by_customer_delivery(delivery_id bigint) returns bigint
    language plpgsql
as
$$
DECLARE
    _previous_quantity DOUBLE PRECISION;
    _new_quantity      DOUBLE PRECISION;
    _row_count         BIGINT;
    _counter           BIGINT;
    _transaction_type  TEXT;
    t_row              customer_delivery_challan_details%rowtype;
    t_delivery         customer_delivery_challans%rowtype;

BEGIN
    SELECT *
    FROM customer_delivery_challans
    WHERE id = delivery_id
    INTO t_delivery;

    _counter := 1;
    FOR t_row IN
        SELECT *
        FROM customer_delivery_challan_details
        WHERE challan_id = delivery_id
        LOOP
            SELECT quantity
            FROM distributor_stocks
            WHERE distributor_id = t_delivery.distributor_id
              AND product_id = t_row.product_id
            INTO _previous_quantity;
            _previous_quantity = coalesce(_previous_quantity, 0.0);

            IF t_delivery.is_active = FALSE
            THEN
                _transaction_type := 'REVERT_CUSTOMER_DELIVERY_CHALLAN';
                _new_quantity := _previous_quantity + t_row.quantity;
            ELSE
                _transaction_type := 'CUSTOMER_DELIVERY_CHALLAN';
                _new_quantity := _previous_quantity - t_row.quantity;
            END IF;

            INSERT INTO distributor_stock_transactions (created_by, created_at, organization_id, distributor_id,
                                                        product_id,
                                                        previous_quantity, quantity, new_quantity, transaction_type,
                                                        distributor_challan_id, customer_challan_id, customer_return_id,
                                                        distributor_return_id, transfer_id, transaction_time)
            VALUES (t_delivery.approved_by, now(), t_delivery.organization_id, t_delivery.distributor_id,
                    t_row.product_id,
                    _previous_quantity, t_row.quantity, _new_quantity, _transaction_type,
                    null, delivery_id, null,
                    null, null, now());
            INSERT INTO distributor_stocks (created_by, organization_id, distributor_id, product_id, quantity)
            VALUES (t_delivery.approved_by, t_delivery.organization_id, t_delivery.distributor_id, t_row.product_id,
                    _new_quantity)
            ON CONFLICT(distributor_id, product_id)
                DO UPDATE SET quantity = _new_quantity;
            _counter := _counter + 1;
        END LOOP;
    RETURN _row_count;
END;
$$;

alter function update_db_stock_transaction_and_stock_by_customer_delivery(bigint) owner to bizmotion_user;

