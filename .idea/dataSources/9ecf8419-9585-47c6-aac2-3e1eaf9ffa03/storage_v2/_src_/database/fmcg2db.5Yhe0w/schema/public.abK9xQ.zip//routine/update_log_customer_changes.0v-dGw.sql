create function update_log_customer_changes() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        INSERT INTO updated_customer(operation, org_id, retailer_id, old_active, new_active)
        VALUES (TG_OP, NEW.organization_id, NEW.id, new.is_active, new.is_active);
        RETURN NEW;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO updated_customer(operation, org_id, retailer_id, old_active, new_active)
        VALUES (TG_OP, NEW.organization_id, OLD.id, OLD.is_active, new.is_active);
        RETURN NEW;
    END IF;
END;
$$;

alter function update_log_customer_changes() owner to bizmotion_user;

