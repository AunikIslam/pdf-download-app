create function update_db_stock_by_delivery_to_retailer(_delivery_id bigint) returns integer
    language plpgsql
as
$$
DECLARE
    t_row record;
BEGIN
    FOR t_row IN
        SELECT t.created_by                         AS created_by,
               t.organization_id                    AS organization_id,
               t.distributor_id                     AS distributor_id,
               t.product_id                         AS product_id,
               s.quantity                           AS previous_quantity,
               t.quantity                           AS quantity,
               CASE
                   WHEN t.active = TRUE THEN s.quantity - t.quantity
                   ELSE s.quantity + t.quantity END AS new_quantity,
               t.transaction_type                   AS transaction_type
        FROM (SELECT c.approved_by                                   AS created_by,
                     c.is_active                                     AS active,
                     c.organization_id                               AS organization_id,
                     c.distributor_id                                AS distributor_id,
                     d.product_id                                    AS product_id,
                     d.quantity                                      AS quantity,
                     CASE
                         WHEN c.is_active = TRUE THEN 'CUSTOMER_DELIVERY_CHALLAN'
                         ELSE 'REVERT_CUSTOMER_DELIVERY_CHALLAN' END AS transaction_type
              FROM customer_delivery_challans c
                       LEFT JOIN customer_delivery_challan_details d on c.id = d.challan_id
              WHERE c.id = _delivery_id) t
                 LEFT JOIN distributor_stocks s ON s.distributor_id = t.distributor_id AND s.product_id = t.product_id
        LOOP
            INSERT INTO distributor_stock_transactions (created_by, created_at, organization_id, distributor_id,
                                                        product_id,
                                                        previous_quantity, quantity, new_quantity, transaction_type,
                                                        customer_challan_id, transaction_time)
            VALUES (t_row.created_by, now(), t_row.organization_id, t_row.distributor_id,
                    t_row.product_id,
                    t_row.previous_quantity, t_row.quantity, t_row.new_quantity, t_row.transaction_type,
                    _delivery_id, now());

            INSERT INTO distributor_stocks (created_by, organization_id, distributor_id, product_id, quantity)
            VALUES (t_row.created_by, t_row.organization_id, t_row.distributor_id, t_row.product_id, t_row.new_quantity)
            ON CONFLICT(distributor_id, product_id)
                DO UPDATE SET quantity = t_row.new_quantity;
        end loop;
    RETURN 1;
END
$$;

alter function update_db_stock_by_delivery_to_retailer(bigint) owner to bizmotion_user;

